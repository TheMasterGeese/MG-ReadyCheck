declare let gameUsers: StoredDocument<User>[];
/**
* Set the status of certain players to "Not Ready"
*
* @param players The players to set status to "Not Ready"
*/
declare function setPlayersToNotReady(players?: User[]): void;
/**
* Create the ready check buttons
*/
declare function createButtons(): void;
/**
* Display the dialogue prompting the GM to either start ready check or set status.
*/
declare function displayGmDialog(): void;
/**
* callback function for the GM's ready check button
*/
declare function initReadyCheckDefault(): void;
/**
* Initiate the ready check, notifying players over discord (if setting is enabled) and in-game to set their ready status.
*
* @param message The message to display in the ready check dialogue and to forward to Discord
*/
declare function initReadyCheck(message: string, users: User[]): Promise<void>;
/**
* Gets an array of users that have a token in the current scene.
* @returns The array of users
*/
declare function getUsersWithTokenInScene(): User[];
/**
* Set up the dialogue to update your ready status.
*/
declare function displayStatusUpdateDialog(): void;
/**
* Display the dialogue asking each user if they are ready
*
* @param message The message to display on the dialogue.
*/
declare function displayReadyCheckDialog(message: string): void;
/**
* button listener that pdates a user's ready status.
* @param data button click event data
*/
declare function updateReadyStatus(data: ReadyCheckUserData): Promise<void>;
/**
* Process a (GM)'s ready repsonse.
* @param data
*/
declare function processReadyResponse(data: ReadyCheckUserData): Promise<void>;
/**
* Checks if all users in a scene are ready.
* @returns Returns true if all users are ready, false otherwise.
*/
declare function allUsersInSceneReady(): boolean;
/**
* Displays a chat message when a user responds to a ready check
*
* @param data event data from clicking either of the buttons to indicate ready/not ready
*/
declare function displayReadyCheckChatMessage(data: ReadyCheckUserData): Promise<void>;
/**
* Display a chat message when a user updates their status.
* @param data event data from clicking either of the buttons to indicate ready/not ready
*/
declare function displayStatusUpdateChatMessage(data: ReadyCheckUserData): Promise<void>;
/**
* Play sound effect associated with ready check start
*/
declare function playReadyCheckAlert(): Promise<void>;
/**
* Updates the ui of each player's ready status.
*/
declare function updatePlayersWindow(): Promise<void>;
/**
* data passed to button listener functions
*/
declare class ReadyCheckUserData {
	action: string;
	ready: boolean;
	userId: string;
}
