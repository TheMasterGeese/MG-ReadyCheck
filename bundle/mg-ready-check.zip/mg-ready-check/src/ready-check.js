"use strict";
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
	function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
	return new (P || (P = Promise))(function (resolve, reject) {
		function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
		function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
		function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
		step((generator = generator.apply(thisArg, _arguments || [])).next());
	});
};
let gameUsers = [];
/**
* Register all settings
*/
Hooks.once("init", function () {
	game.settings.register("mg-ready-check", "showChatMessagesForUserUpdates", {
		name: game.i18n.localize("READYCHECK.SettingsChatMessagesForUserUpdatesTitle"),
		hint: game.i18n.localize("READYCHECK.SettingsChatMessagesForUserUpdatesHint"),
		scope: "world",
		config: true,
		default: true,
		type: Boolean
	});
	game.settings.register("mg-ready-check", "showChatMessagesForChecks", {
		name: game.i18n.localize("READYCHECK.SettingsChatMessagesForChecksTitle"),
		hint: game.i18n.localize("READYCHECK.SettingsChatMessagesForChecksHint"),
		scope: "world",
		config: true,
		default: false,
		type: Boolean
	});
	game.settings.register("mg-ready-check", "playAlertForCheck", {
		name: game.i18n.localize("READYCHECK.SettingsPlayAlertForChecksTitle"),
		hint: game.i18n.localize("READYCHECK.SettingsPlayAlertForChecksHint"),
		scope: "world",
		config: true,
		default: false,
		type: Boolean
	});
	game.settings.register("mg-ready-check", "checkAlertSoundPath", {
		name: game.i18n.localize("READYCHECK.SettingsCheckAlertSoundPathTitle"),
		hint: game.i18n.localize("READYCHECK.SettingsCheckAlertSoundPathHint"),
		scope: "world",
		config: true,
		default: 'modules/mg-ready-check/sounds/notification.mp3',
		type: String
	});
	game.settings.register("mg-ready-check", "enableDiscordIntegration", {
		name: game.i18n.localize("READYCHECK.SettingsEnableDiscordIntegrationTitle"),
		hint: game.i18n.localize("READYCHECK.SettingsEnableDiscordIntegrationHint"),
		scope: "world",
		config: true,
		default: false,
		type: Boolean
	});
	game.settings.register("mg-ready-check", "statusResetOnLoad", {
		name: game.i18n.localize("READYCHECK.SettingsStatusResetOnLoadTitle"),
		hint: game.i18n.localize("READYCHECK.SettingsStatusResetOnLoadHint"),
		scope: "world",
		config: true,
		default: true,
		type: Boolean
	});
	game.settings.register("mg-ready-check", "pauseOnReadyCheck", {
		name: game.i18n.localize("READYCHECK.SettingsPauseOnReadyCheckTitle"),
		hint: game.i18n.localize("READYCHECK.SettingsPauseOnReadyCheckHint"),
		scope: "world",
		config: true,
		default: true,
		type: Boolean
	});
	game.settings.register("mg-ready-check", "unpauseOnAllReady", {
		name: game.i18n.localize("READYCHECK.SettingsUnpauseOnAllReadyTitle"),
		hint: game.i18n.localize("READYCHECK.SettingsUnpauseOnAllReadyHint"),
		scope: "world",
		config: true,
		default: true,
		type: Boolean
	});
});
// Render the status symbols and if the setting is enabled, reset all statuses.
Hooks.once("ready", function () {
	return __awaiter(this, void 0, void 0, function* () {
		gameUsers = game.users.contents;
		if (game.settings.get('mg-ready-check', 'statusResetOnLoad') && game.user.isGM) {
			setPlayersToNotReady();
		}
		yield updatePlayersWindow();
	});
});
// Set Up Buttons and Socket Stuff
Hooks.on('renderChatLog', function () {
	createButtons();
	if (socket) {
		// create the socket handler
		socket.on('module.mg-ready-check', (data) => __awaiter(this, void 0, void 0, function* () {
			if (data.action === 'check') {
				displayReadyCheckDialog(game.i18n.localize("READYCHECK.DialogContentReadyCheck"));
			}
			else if (data.action === 'update') {
				yield processReadyResponse(data);
			}
			else {
				console.error("Unrecognized ready check action");
			}
		}));
	}
});
// Update the display of the Player UI.
Hooks.on('renderPlayerList', function () {
	return __awaiter(this, void 0, void 0, function* () {
		yield updatePlayersWindow();
	});
});
/**
* Initiate a ready check
*
* @param message The prompt to display for the ready check
* @param users The users to include in the ready check. Defaults to all Users.
*/
Hooks.on('initReadyCheck', function (message = game.i18n.localize("READYCHECK.DialogContentReadyCheck"), users) {
	return __awaiter(this, void 0, void 0, function* () {
		if (game.user.isGM) {
			yield initReadyCheck(message, users !== null && users !== void 0 ? users : getUsersWithTokenInScene());
		}
		else {
			ui.notifications.error(game.i18n.localize("READYCHECK.ErrorNotGM"));
		}
	});
});
/**
* Set the status of certain players to "Not Ready"
*
* @param players The players to set status to "Not Ready"
*/
function setPlayersToNotReady(players = gameUsers) {
	players.forEach((user) => {
		user.setFlag('mg-ready-check', 'isReady', false).catch(reason => {
			console.error(reason);
		});
	});
}
/**
* Create the ready check buttons
*/
function createButtons() {
	//set title based on whether the user is player or GM
	const btnTitle = game.user.role === 4 ? game.i18n.localize("READYCHECK.UiGmButton") : game.i18n.localize("READYCHECK.UiChangeButton");
	const sidebarBtn = $(`<a class="crash-ready-check-sidebar" title="${btnTitle}"><i class="fas fa-hourglass-half"></i></a>`);
	const popoutBtn = $(`<a class="crash-ready-check-popout" title="${btnTitle}"><i class="fas fa-hourglass-half"></i></a>`);
	const sidebarDiv = $("#sidebar").find(".chat-control-icon");
	const popoutDiv = $("#chat-popout").find(".chat-control-icon");
	const btnAlreadyInSidebar = $("#sidebar").find(".crash-ready-check-sidebar").length > 0;
	const btnAlreadyInPopout = $("#chat-popout").find(".crash-ready-check-popout").length > 0;
	// Add the button to the sidebar if it doesn't already exist
	if (!btnAlreadyInSidebar) {
		sidebarDiv.before(sidebarBtn);
		jQuery(".crash-ready-check-sidebar").on("click", readyCheckOnClick);
	}
	// Add the button to the popout if it doesn't already exist
	if (!btnAlreadyInPopout) {
		popoutDiv.before(popoutBtn);
		jQuery(".crash-ready-check-popout").on("click", readyCheckOnClick);
	}
	/**
	* Ready check button listener
	* @param event the button click event
	*/
	function readyCheckOnClick(event) {
		event.preventDefault();
		if (game.user.role === 4) {
			displayGmDialog();
		}
		else {
			displayStatusUpdateDialog();
		}
	}
}
/**
* Display the dialogue prompting the GM to either start ready check or set status.
*/
function displayGmDialog() {
	const buttons = {
		check: {
			icon: "<i class='fas fa-check'></i>",
			label: game.i18n.localize("READYCHECK.GmDialogButtonCheck"),
			callback: initReadyCheckDefault
		},
		status: {
			icon: "<i class='fas fa-hourglass-half'></i>",
			label: game.i18n.localize("READYCHECK.GmDialogButtonStatus"),
			callback: displayStatusUpdateDialog
		}
	};
	new Dialog({
		title: game.i18n.localize("READYCHECK.GmDialogTitle"),
		content: `<p>${game.i18n.localize("READYCHECK.GmDialogContent")}</p>`,
		buttons: buttons,
		default: "check"
	}).render(true);
}
/**
* callback function for the GM's ready check button
*/
function initReadyCheckDefault() {
	Hooks.callAll("initReadyCheck");
}
/**
* Initiate the ready check, notifying players over discord (if setting is enabled) and in-game to set their ready status.
*
* @param message The message to display in the ready check dialogue and to forward to Discord
*/
function initReadyCheck(message = game.i18n.localize("READYCHECK.DialogContentReadyCheck"), users) {
	return __awaiter(this, void 0, void 0, function* () {
		if (game.settings.get('mg-ready-check', 'pauseOnReadyCheck') && !game.paused) {
			game.togglePause(true, true);
		}
		const data = { action: 'check' };
		setPlayersToNotReady(users);
		if (socket) {
			socket.emit('module.mg-ready-check', data);
		}
		displayReadyCheckDialog(message);
		yield playReadyCheckAlert();
		if (game.settings.get('mg-ready-check', 'enableDiscordIntegration')) {
			// For every user in the game, if they have a token in the current scene, ping them as part of the ready check message.
			getUsersWithTokenInScene().forEach((user) => {
				message = `@${user.name} ${message}`;
			});
			Hooks.callAll("sendDiscordMessage", message);
		}
	});
}
/**
* Gets an array of users that have a token in the current scene.
* @returns The array of users
*/
function getUsersWithTokenInScene() {
	const usersInScene = [];
	gameUsers.forEach((user) => {
		const scene = game.scenes.active;
		scene.data.tokens.forEach((token) => {
			// permissions object that maps user ids to permission enums
			const tokenPermissions = game.actors.get(token.data.actorId).data.permission;
			// if the user owns this token, then they are in the scene.
			if (tokenPermissions[user.id] === 3 && !usersInScene.includes(user)) {
				usersInScene.push(user);
			}
		});
	});
	return usersInScene;
}
/**
* Set up the dialogue to update your ready status.
*/
function displayStatusUpdateDialog() {
	var _a;
	const data = { action: 'update', ready: false, userId: (_a = game.userId) !== null && _a !== void 0 ? _a : "" };
	const buttons = {
		yes: {
			icon: "<i class='fas fa-check'></i>",
			label: game.i18n.localize("READYCHECK.StatusReady"),
			callback: () => __awaiter(this, void 0, void 0, function* () { data.ready = true; yield updateReadyStatus(data); yield displayStatusUpdateChatMessage(data); })
		},
		no: {
			icon: "<i class='fas fa-times'></i>",
			label: game.i18n.localize("READYCHECK.StatusNotReady"),
			callback: () => __awaiter(this, void 0, void 0, function* () { data.ready = false; yield updateReadyStatus(data); yield displayStatusUpdateChatMessage(data); })
		}
	};
	new Dialog({
		title: game.i18n.localize("READYCHECK.DialogTitleStatusUpdate"),
		content: `<p>${game.i18n.localize("READYCHECK.DialogContentStatusUpdate")}</p>`,
		buttons: buttons,
		default: "yes"
	}).render(true);
}
// 
/**
* Display the dialogue asking each user if they are ready
*
* @param message The message to display on the dialogue.
*/
function displayReadyCheckDialog(message) {
	var _a;
	const data = { action: 'update', ready: false, userId: (_a = game.userId) !== null && _a !== void 0 ? _a : "" };
	const buttons = {
		yes: {
			icon: "<i class='fas fa-check'></i>",
			label: game.i18n.localize("READYCHECK.StatusReady"),
			callback: () => __awaiter(this, void 0, void 0, function* () { data.ready = true; yield updateReadyStatus(data); yield displayReadyCheckChatMessage(data); })
		}
	};
	new Dialog({
		title: game.i18n.localize("READYCHECK.DialogTitleReadyCheck"),
		content: `<p>${message}</p>`,
		buttons: buttons,
		default: "yes"
	}).render(true);
}
/**
* button listener that pdates a user's ready status.
* @param data button click event data
*/
function updateReadyStatus(data) {
	return __awaiter(this, void 0, void 0, function* () {
		// If the user is a GM, just update it since the socket go to the sender, and none of the recipients (players)
		// will have the permissions require to update user flags. If the user is not a GM, emit that socket.
		if (game.user.isGM) {
			yield processReadyResponse(data);
		}
		else if (socket) {
			socket.emit('module.mg-ready-check', data);
		}
	});
}
/**
* Process a (GM)'s ready repsonse.
* @param data
*/
function processReadyResponse(data) {
	return __awaiter(this, void 0, void 0, function* () {
		if (game.user.isGM) {
			const userToUpdate = gameUsers.find((user) => user.id === data.userId);
			if (userToUpdate) {
				yield userToUpdate.setFlag('mg-ready-check', 'isReady', data.ready);
				ui.players.render();
				let message;
				if (allUsersInSceneReady()) {
					// Unpause the game if the setting to do so is enabled.
					if (game.settings.get('mg-ready-check', 'unpauseOnAllReady') && game.paused) {
						game.togglePause(false, true);
					}
					// Send a message to the GM indicating that all users are ready.
					message = `@${game.user.name} `.concat(game.i18n.localize("READYCHECK.AllPlayersReady"));
					const usersInScene = getUsersWithTokenInScene();
					if (game.settings.get('mg-ready-check', 'enableDiscordIntegration')
						&& usersInScene.find(user => user.id === userToUpdate.id)) {
						Hooks.callAll("sendDiscordMessage", message);
					}
				}
			}
			else {
				console.error(`The user with the id ${data.userId} was not found.`);
			}
		}
	});
}
/**
* Checks if all users in a scene are ready.
* @returns Returns true if all users are ready, false otherwise.
*/
function allUsersInSceneReady() {
	let usersReady = true;
	const sceneUsers = getUsersWithTokenInScene();
	sceneUsers.forEach((user) => {
		if (!user.getFlag('mg-ready-check', 'isReady')) {
			usersReady = false;
		}
	});
	return usersReady;
}
/**
* Displays a chat message when a user responds to a ready check
*
* @param data event data from clicking either of the buttons to indicate ready/not ready
*/
function displayReadyCheckChatMessage(data) {
	return __awaiter(this, void 0, void 0, function* () {
		if (game.settings.get("mg-ready-check", "showChatMessagesForChecks")) {
			// Find the current user
			const currentUser = gameUsers.find((user) => user.data._id === data.userId);
			if (currentUser) {
				const username = currentUser.data.name;
				const content = `${username} ${game.i18n.localize("READYCHECK.ChatTextCheck")}`;
				yield ChatMessage.create({ speaker: { alias: "Ready Set Go!" }, content: content });
			}
			else {
				throw new Error(`The user with the id ${data.userId} was not found.`);
			}
		}
	});
}
/**
* Display a chat message when a user updates their status.
* @param data event data from clicking either of the buttons to indicate ready/not ready
*/
function displayStatusUpdateChatMessage(data) {
	return __awaiter(this, void 0, void 0, function* () {
		if (game.settings.get("mg-ready-check", "showChatMessagesForUserUpdates")) {
			const currentUser = gameUsers.find((user) => user.id === data.userId);
			if (currentUser) {
				const username = currentUser.data.name;
				const status = data.ready ? game.i18n.localize("READYCHECK.StatusReady") : game.i18n.localize("READYCHECK.StatusNotReady");
				const content = `${username} ${game.i18n.localize("READYCHECK.ChatTextUserUpdate")} ${status}`;
				yield ChatMessage.create({ speaker: { alias: "Ready Set Go!" }, content: content });
			}
			else {
				throw new Error(`The user with the id ${data.userId} was not found.`);
			}
		}
	});
}
/**
* Play sound effect associated with ready check start
*/
function playReadyCheckAlert() {
	return __awaiter(this, void 0, void 0, function* () {
		const playAlert = game.settings.get("mg-ready-check", "playAlertForCheck");
		const alertSound = game.settings.get("mg-ready-check", "checkAlertSoundPath");
		if (playAlert && !alertSound) {
			yield AudioHelper.play({ src: "modules/mg-ready-check/sounds/notification.mp3", volume: 1, autoplay: true, loop: false }, true);
		}
		else if (playAlert && alertSound) {
			yield AudioHelper.play({ src: alertSound, volume: 1, autoplay: true, loop: false }, true);
		}
	});
}
/**
* Updates the ui of each player's ready status.
*/
function updatePlayersWindow() {
	return __awaiter(this, void 0, void 0, function* () {
		for (let i = 0; i < gameUsers.length; i++) {
			// Is the user ready
			const ready = yield gameUsers[i].getFlag('mg-ready-check', 'isReady');
			// the Id of the current user
			const userId = gameUsers[i].data._id;
			// get the ready/not ready indicator
			const indicator = $("#players").find(`[data-user-id=${userId}] .crash-ready-indicator`);
			const indicatorExists = indicator.length > 0;
			let title;
			let classToAdd, classToRemove, iconClassToAdd, iconClassToRemove;
			if (ready) {
				title = game.i18n.localize("READYCHECK.PlayerReady");
				classToAdd = "ready";
				classToRemove = "not-ready";
				iconClassToAdd = "fa-check";
				iconClassToRemove = "fa-times";
			}
			else {
				title = game.i18n.localize("READYCHECK.PlayerNotReady");
				classToAdd = "not-ready";
				classToRemove = "ready";
				iconClassToAdd = "fa-times";
				iconClassToRemove = "fa-check";
			}
			if (indicatorExists) {
				$(indicator).removeClass(classToRemove);
				$(indicator).removeClass(iconClassToRemove);
				$(indicator).addClass(classToAdd);
				$(indicator).addClass(iconClassToAdd);
			}
			else {
				// Create a new indicator
				$("#players").find("[data-user-id=" + userId + "]").append(`<i class="fas ${iconClassToAdd} crash-ready-indicator ${classToAdd}" title="${title}"></i>`);
			}
		}
	});
}
/**
* data passed to button listener functions
*/
class ReadyCheckUserData {
	constructor() {
		this.action = "";
		this.ready = false;
		this.userId = "";
	}
}
