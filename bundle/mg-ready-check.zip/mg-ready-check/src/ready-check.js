"use strict";
/* eslint-disable @typescript-eslint/await-thenable */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const popoutBtnFile = 'modules/mg-ready-check/handlebars/popoutBtn.hbs';
const sidebarBtnFile = 'modules/mg-ready-check/handlebars/sidebarBtn.hbs';
const readyIndicatorFile = 'modules/mg-ready-check/handlebars/readyIndicator.hbs';
/**
 * Register all settings
 */
Hooks.once("init", function () {
    game.settings.register("mg-ready-check", "showChatMessagesForUserUpdates", {
        name: game.i18n.localize("READYCHECK.SettingsChatMessagesForUserUpdatesTitle"),
        hint: game.i18n.localize("READYCHECK.SettingsChatMessagesForUserUpdatesHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    game.settings.register("mg-ready-check", "showChatMessagesForChecks", {
        name: game.i18n.localize("READYCHECK.SettingsChatMessagesForChecksTitle"),
        hint: game.i18n.localize("READYCHECK.SettingsChatMessagesForChecksHint"),
        scope: "world",
        config: true,
        default: false,
        type: Boolean
    });
    game.settings.register("mg-ready-check", "playAlertForCheck", {
        name: game.i18n.localize("READYCHECK.SettingsPlayAlertForChecksTitle"),
        hint: game.i18n.localize("READYCHECK.SettingsPlayAlertForChecksHint"),
        scope: "world",
        config: true,
        default: false,
        type: Boolean
    });
    game.settings.register("mg-ready-check", "checkAlertSoundPath", {
        name: game.i18n.localize("READYCHECK.SettingsCheckAlertSoundPathTitle"),
        hint: game.i18n.localize("READYCHECK.SettingsCheckAlertSoundPathHint"),
        scope: "world",
        config: true,
        default: 'modules/mg-ready-check/sounds/notification.mp3',
        type: String
    });
    game.settings.register("mg-ready-check", "enableDiscordIntegration", {
        name: game.i18n.localize("READYCHECK.SettingsEnableDiscordIntegrationTitle"),
        hint: game.i18n.localize("READYCHECK.SettingsEnableDiscordIntegrationHint"),
        scope: "world",
        config: true,
        default: false,
        type: Boolean
    });
    game.settings.register("mg-ready-check", "statusResetOnLoad", {
        name: game.i18n.localize("READYCHECK.SettingsStatusResetOnLoadTitle"),
        hint: game.i18n.localize("READYCHECK.SettingsStatusResetOnLoadHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    game.settings.register("mg-ready-check", "pauseOnReadyCheck", {
        name: game.i18n.localize("READYCHECK.SettingsPauseOnReadyCheckTitle"),
        hint: game.i18n.localize("READYCHECK.SettingsPauseOnReadyCheckHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
    game.settings.register("mg-ready-check", "unpauseOnAllReady", {
        name: game.i18n.localize("READYCHECK.SettingsUnpauseOnAllReadyTitle"),
        hint: game.i18n.localize("READYCHECK.SettingsUnpauseOnAllReadyHint"),
        scope: "world",
        config: true,
        default: true,
        type: Boolean
    });
});
// Render the status symbols and if the setting is enabled, reset all statuses.
Hooks.once("ready", function () {
    return __awaiter(this, void 0, void 0, function* () {
        yield loadTemplates([
            popoutBtnFile,
            sidebarBtnFile,
            readyIndicatorFile
        ]);
        if (game.settings.get('mg-ready-check', 'statusResetOnLoad') && game.user.role === 4) {
            setPlayersToNotReady();
        }
        yield updatePlayersWindow();
        if (socket) {
            // create the socket handler
            socket.on('module.mg-ready-check', (data) => __awaiter(this, void 0, void 0, function* () {
                var _a;
                if (data.action === 'check') {
                    displayReadyCheckDialog((_a = data.dialog) !== null && _a !== void 0 ? _a : game.i18n.localize("READYCHECK.DialogContentReadyCheck"));
                }
                else if (data.action === 'update') {
                    yield processReadyResponse(data);
                }
                else {
                    console.error("Unrecognized ready check action");
                }
            }));
        }
    });
});
// Set Up Buttons and Socket Stuff
Hooks.on('renderChatLog', function () {
    return __awaiter(this, void 0, void 0, function* () {
        yield createButtons();
    });
});
// Update the display of the Player UI.
Hooks.on('renderPlayerList', function () {
    return __awaiter(this, void 0, void 0, function* () {
        yield updatePlayersWindow();
    });
});
/**
 * Initiate a ready check
 *
 * @param message The prompt to display for the ready check
 * @param users The users to include in the ready check. Defaults to all Users.
 */
Hooks.on('initReadyCheck', function (message = game.i18n.localize("READYCHECK.DialogContentReadyCheck"), users) {
    return __awaiter(this, void 0, void 0, function* () {
        yield initReadyCheck(message, users !== null && users !== void 0 ? users : getUsersWithTokenInScene());
    });
});
/**
 * Set the status of certain players to "Not Ready"
 *
 * @param players The players to set status to "Not Ready"
 */
function setPlayersToNotReady(players = game.users.contents) {
    players.forEach((user) => {
        user.setFlag('mg-ready-check', 'isReady', false).catch(reason => {
            console.error(reason);
        });
    });
}
/**
 * Create the ready check buttons
 */
function createButtons() {
    return __awaiter(this, void 0, void 0, function* () {
        //set title based on whether the user is player or GM
        const btnTitle = game.user.role === 4 ? game.i18n.localize("READYCHECK.UiGmButton") : game.i18n.localize("READYCHECK.UiChangeButton");
        const sidebarBtn = $(yield renderTemplate(sidebarBtnFile, {
            btnTitle: btnTitle
        }));
        const popoutBtn = $(yield renderTemplate(popoutBtnFile, {
            btnTitle: btnTitle
        }));
        const sidebarDiv = $("#sidebar").find(".chat-control-icon");
        const popoutDiv = $("#chat-popout").find(".chat-control-icon");
        const btnAlreadyInSidebar = $("#sidebar").find(".crash-ready-check-sidebar").length > 0;
        const btnAlreadyInPopout = $("#chat-popout").find(".crash-ready-check-popout").length > 0;
        // Add the button to the sidebar if it doesn't already exist
        if (!btnAlreadyInSidebar) {
            sidebarDiv.before(sidebarBtn);
            jQuery(".crash-ready-check-sidebar").on("click", readyCheckOnClick);
        }
        // Add the button to the popout if it doesn't already exist
        if (!btnAlreadyInPopout) {
            popoutDiv.before(popoutBtn);
            jQuery(".crash-ready-check-popout").on("click", readyCheckOnClick);
        }
        /**
         * Ready check button listener
         * @param event the button click event
         */
        function readyCheckOnClick(event) {
            event.preventDefault();
            if (game.user.role === 4) {
                displayGmDialog();
            }
            else {
                displayStatusUpdateDialog();
            }
        }
    });
}
/**
 * Display the dialogue prompting the GM to either start ready check or set status.
 */
function displayGmDialog() {
    const buttons = {
        check: {
            icon: "<i class='fas fa-check'></i>",
            label: game.i18n.localize("READYCHECK.GmDialogButtonCheck"),
            callback: initReadyCheckDefault
        },
        status: {
            icon: "<i class='fas fa-hourglass-half'></i>",
            label: game.i18n.localize("READYCHECK.GmDialogButtonStatus"),
            callback: displayStatusUpdateDialog
        }
    };
    new Dialog({
        title: game.i18n.localize("READYCHECK.GmDialogTitle"),
        content: `<p>${game.i18n.localize("READYCHECK.GmDialogContent")}</p>`,
        buttons: buttons,
        default: "check"
    }).render(true);
}
/**
 * callback function for the GM's ready check button
 */
function initReadyCheckDefault() {
    Hooks.callAll("initReadyCheck");
}
/**
 * Initiate the ready check, notifying players over discord (if setting is enabled) and in-game to set their ready status.
 *
 * @param message The message to display in the ready check dialogue and to forward to Discord
 */
function initReadyCheck(message = game.i18n.localize("READYCHECK.DialogContentReadyCheck"), users) {
    return __awaiter(this, void 0, void 0, function* () {
        if (game.settings.get('mg-ready-check', 'pauseOnReadyCheck') && !game.paused) {
            game.togglePause(true, true);
        }
        const data = { action: 'check', dialog: message };
        setPlayersToNotReady(users);
        if (socket) {
            socket.emit('module.mg-ready-check', data);
        }
        displayReadyCheckDialog(message);
        yield playReadyCheckAlert();
        if (game.settings.get('mg-ready-check', 'enableDiscordIntegration')) {
            // For every user in the game, if they have a token in the current scene, ping them as part of the ready check message.
            getUsersWithTokenInScene().forEach((user) => {
                message = `@${user.name} ${message}`;
            });
            Hooks.callAll("sendDiscordMessage", message);
        }
    });
}
/**
 * Gets an array of users that have a token in the current scene.
 * @returns The array of users
 */
function getUsersWithTokenInScene() {
    const usersInScene = [];
    game.users.contents.forEach((user) => {
        const scene = game.scenes.active;
        scene.data.tokens.forEach((token) => {
            // permissions object that maps user ids to permission enums
            const tokenPermissions = game.actors.get(token.data.actorId).data.permission;
            // if the user owns this token, then they are in the scene.
            if (tokenPermissions[user.id] === 3 && !usersInScene.includes(user)) {
                usersInScene.push(user);
            }
        });
    });
    return usersInScene;
}
/**
 * Set up the dialogue to update your ready status.
 */
function displayStatusUpdateDialog() {
    var _a;
    const data = { action: 'update', ready: false, userId: (_a = game.userId) !== null && _a !== void 0 ? _a : "" };
    const buttons = {
        yes: {
            icon: "<i class='fas fa-check'></i>",
            label: game.i18n.localize("READYCHECK.StatusReady"),
            callback: () => __awaiter(this, void 0, void 0, function* () { data.ready = true; yield updateReadyStatus(data); yield displayStatusUpdateChatMessage(data); })
        },
        no: {
            icon: "<i class='fas fa-times'></i>",
            label: game.i18n.localize("READYCHECK.StatusNotReady"),
            callback: () => __awaiter(this, void 0, void 0, function* () { data.ready = false; yield updateReadyStatus(data); yield displayStatusUpdateChatMessage(data); })
        }
    };
    new Dialog({
        title: game.i18n.localize("READYCHECK.DialogTitleStatusUpdate"),
        content: `<p>${game.i18n.localize("READYCHECK.DialogContentStatusUpdate")}</p>`,
        buttons: buttons,
        default: "yes"
    }).render(true);
}
// 
/**
 * Display the dialogue asking each user if they are ready
 *
 * @param message The message to display on the dialogue.
 */
function displayReadyCheckDialog(message) {
    var _a;
    const data = { action: 'update', ready: false, userId: (_a = game.userId) !== null && _a !== void 0 ? _a : "", dialog: message };
    const buttons = {
        yes: {
            icon: "<i class='fas fa-check'></i>",
            label: game.i18n.localize("READYCHECK.StatusReady"),
            callback: () => __awaiter(this, void 0, void 0, function* () { data.ready = true; yield updateReadyStatus(data); yield displayReadyCheckChatMessage(data); })
        }
    };
    new Dialog({
        title: game.i18n.localize("READYCHECK.DialogTitleReadyCheck"),
        content: `<p>${data.dialog}</p>`,
        buttons: buttons,
        default: "yes"
    }).render(true);
}
/**
 * button listener that pdates a user's ready status.
 * @param data button click event data
 */
function updateReadyStatus(data) {
    return __awaiter(this, void 0, void 0, function* () {
        // If the user is a GM, just update it since the socket go to the sender, and none of the recipients (players)
        // will have the permissions require to update user flags. If the user is not a GM, emit that socket.
        if (isProxyGM(game.user)) {
            yield processReadyResponse(data);
        }
        else if (socket) {
            socket.emit('module.mg-ready-check', data);
        }
    });
}
/**
 * Process a (GM)'s ready repsonse.
 * @param data
 */
function processReadyResponse(data) {
    return __awaiter(this, void 0, void 0, function* () {
        if (isProxyGM(game.user)) {
            const userToUpdate = game.users.contents.find((user) => user.id === data.userId);
            if (userToUpdate) {
                yield userToUpdate.setFlag('mg-ready-check', 'isReady', data.ready);
                ui.players.render();
                let message = "";
                if (allUsersInSceneReady()) {
                    // Unpause the game if the setting to do so is enabled.
                    if (game.settings.get('mg-ready-check', 'unpauseOnAllReady') && game.paused) {
                        game.togglePause(false, true);
                    }
                    const usersInScene = getUsersWithTokenInScene();
                    if (game.settings.get('mg-ready-check', 'enableDiscordIntegration')
                        && usersInScene.find(user => user.id === userToUpdate.id)) {
                        // We want to only ping the GMs that have a setting indicating that they should be pinged for this notification.
                        game.users.contents.forEach((user) => {
                            const shouldPing = user.getFlag('discord-integration', 'sendGMNotifications');
                            if (shouldPing) {
                                message += `@${user.name} `;
                            }
                        });
                        // Send a message to the GM(s) indicating that all users are ready.
                        message += game.i18n.localize("READYCHECK.AllPlayersReady");
                        Hooks.callAll("sendDiscordMessage", message);
                    }
                }
            }
            else {
                console.error(`The user with the id ${data.userId} was not found.`);
            }
        }
    });
}
/**
 * Checks if all users in a scene are ready.
 * @returns Returns true if all users are ready, false otherwise.
 */
function allUsersInSceneReady() {
    let usersReady = true;
    const sceneUsers = getUsersWithTokenInScene();
    sceneUsers.forEach((user) => {
        if (!user.getFlag('mg-ready-check', 'isReady')) {
            usersReady = false;
        }
    });
    return usersReady;
}
/**
 * Displays a chat message when a user responds to a ready check
 *
 * @param data event data from clicking either of the buttons to indicate ready/not ready
 */
function displayReadyCheckChatMessage(data) {
    return __awaiter(this, void 0, void 0, function* () {
        if (game.settings.get("mg-ready-check", "showChatMessagesForChecks")) {
            // Find the current user
            const currentUser = game.users.contents.find((user) => user.data._id === data.userId);
            if (currentUser) {
                const username = currentUser.data.name;
                const content = `${username} ${game.i18n.localize("READYCHECK.ChatTextCheck")}`;
                yield ChatMessage.create({ speaker: { alias: "Ready Set Go!" }, content: content });
            }
            else {
                throw new Error(`The user with the id ${data.userId} was not found.`);
            }
        }
    });
}
/**
 * Display a chat message when a user updates their status.
 * @param data event data from clicking either of the buttons to indicate ready/not ready
 */
function displayStatusUpdateChatMessage(data) {
    return __awaiter(this, void 0, void 0, function* () {
        if (game.settings.get("mg-ready-check", "showChatMessagesForUserUpdates")) {
            const currentUser = game.users.contents.find((user) => user.id === data.userId);
            if (currentUser) {
                const username = currentUser.data.name;
                const status = data.ready ? game.i18n.localize("READYCHECK.StatusReady") : game.i18n.localize("READYCHECK.StatusNotReady");
                const content = `${username} ${game.i18n.localize("READYCHECK.ChatTextUserUpdate")} ${status}`;
                yield ChatMessage.create({ speaker: { alias: "Ready Set Go!" }, content: content });
            }
            else {
                throw new Error(`The user with the id ${data.userId} was not found.`);
            }
        }
    });
}
/**
 * Play sound effect associated with ready check start
 */
function playReadyCheckAlert() {
    return __awaiter(this, void 0, void 0, function* () {
        const playAlert = game.settings.get("mg-ready-check", "playAlertForCheck");
        const alertSound = game.settings.get("mg-ready-check", "checkAlertSoundPath");
        if (playAlert && !alertSound) {
            yield AudioHelper.play({ src: "modules/mg-ready-check/sounds/notification.mp3", volume: 1, autoplay: true, loop: false }, true);
        }
        else if (playAlert && alertSound) {
            yield AudioHelper.play({ src: alertSound, volume: 1, autoplay: true, loop: false }, true);
        }
    });
}
/**
 * Updates the ui of each player's ready status.
 */
function updatePlayersWindow() {
    return __awaiter(this, void 0, void 0, function* () {
        const gameUsers = game.users.contents;
        for (let i = 0; i < gameUsers.length; i++) {
            // Is the user ready
            const ready = yield gameUsers[i].getFlag('mg-ready-check', 'isReady');
            // the Id of the current user
            const userId = gameUsers[i].data._id;
            // get the ready/not ready indicator
            const indicator = $("#players").find(`[data-user-id=${userId}] .crash-ready-indicator`);
            const indicatorExists = indicator.length > 0;
            let title;
            let classToAdd, classToRemove, iconClassToAdd, iconClassToRemove;
            if (ready) {
                title = game.i18n.localize("READYCHECK.PlayerReady");
                classToAdd = "ready";
                classToRemove = "not-ready";
                iconClassToAdd = "fa-check";
                iconClassToRemove = "fa-times";
            }
            else {
                title = game.i18n.localize("READYCHECK.PlayerNotReady");
                classToAdd = "not-ready";
                classToRemove = "ready";
                iconClassToAdd = "fa-times";
                iconClassToRemove = "fa-check";
            }
            if (indicatorExists) {
                $(indicator).removeClass(classToRemove);
                $(indicator).removeClass(iconClassToRemove);
                $(indicator).addClass(classToAdd);
                $(indicator).addClass(iconClassToAdd);
            }
            else {
                // Create a new indicator
                $("#players").find("[data-user-id=" + userId + "]").append(yield renderTemplate(readyIndicatorFile, {
                    iconClassToAdd: iconClassToAdd,
                    classToAdd: classToAdd,
                    title: title
                }));
            }
        }
    });
}
function isProxyGM(user) {
    const proxyGMId = game.settings.get("mg-living-world-core", "GMProxy");
    return user.id === proxyGMId;
}
/**
 * data passed to button listener functions
 */
class ReadyCheckUserData {
    constructor() {
        this.action = "";
        this.ready = false;
        this.userId = "";
        this.dialog = "";
    }
}

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9yZWFkeS1jaGVjay50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsc0RBQXNEO0FBQ3RELHFFQUFxRTtBQUNyRSwwREFBMEQ7QUFDMUQsc0RBQXNEO0FBQ3RELCtEQUErRDtBQUMvRCw0REFBNEQ7Ozs7Ozs7Ozs7QUFFNUQsTUFBTSxhQUFhLEdBQUcsaURBQWlELENBQUM7QUFDeEUsTUFBTSxjQUFjLEdBQUcsa0RBQWtELENBQUM7QUFDMUUsTUFBTSxrQkFBa0IsR0FBRyxzREFBc0QsQ0FBQztBQUNsRjs7R0FFRztBQUNILEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO0lBRWxCLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLGdCQUFnQixFQUFFLGdDQUFnQyxFQUFFO1FBQzFFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxvREFBb0QsQ0FBQztRQUM5RSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsbURBQW1ELENBQUM7UUFDN0UsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FDYixDQUFDLENBQUM7SUFFSCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSwyQkFBMkIsRUFBRTtRQUNyRSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsK0NBQStDLENBQUM7UUFDekUsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLDhDQUE4QyxDQUFDO1FBQ3hFLEtBQUssRUFBRSxPQUFPO1FBQ2QsTUFBTSxFQUFFLElBQUk7UUFDWixPQUFPLEVBQUUsS0FBSztRQUNkLElBQUksRUFBRSxPQUFPO0tBQ2IsQ0FBQyxDQUFDO0lBRUgsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsbUJBQW1CLEVBQUU7UUFDN0QsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLDRDQUE0QyxDQUFDO1FBQ3RFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywyQ0FBMkMsQ0FBQztRQUNyRSxLQUFLLEVBQUUsT0FBTztRQUNkLE1BQU0sRUFBRSxJQUFJO1FBQ1osT0FBTyxFQUFFLEtBQUs7UUFDZCxJQUFJLEVBQUUsT0FBTztLQUNiLENBQUMsQ0FBQztJQUVILElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLGdCQUFnQixFQUFFLHFCQUFxQixFQUFFO1FBQy9ELElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyw2Q0FBNkMsQ0FBQztRQUN2RSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsNENBQTRDLENBQUM7UUFDdEUsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxnREFBZ0Q7UUFDekQsSUFBSSxFQUFFLE1BQU07S0FDWixDQUFDLENBQUM7SUFFSCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSwwQkFBMEIsRUFBRTtRQUNwRSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsa0RBQWtELENBQUM7UUFDNUUsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGlEQUFpRCxDQUFDO1FBQzNFLEtBQUssRUFBRSxPQUFPO1FBQ2QsTUFBTSxFQUFFLElBQUk7UUFDWixPQUFPLEVBQUUsS0FBSztRQUNkLElBQUksRUFBRSxPQUFPO0tBQ2IsQ0FBQyxDQUFDO0lBRUgsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsbUJBQW1CLEVBQUU7UUFDN0QsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLDJDQUEyQyxDQUFDO1FBQ3JFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywwQ0FBMEMsQ0FBQztRQUNwRSxLQUFLLEVBQUUsT0FBTztRQUNkLE1BQU0sRUFBRSxJQUFJO1FBQ1osT0FBTyxFQUFFLElBQUk7UUFDYixJQUFJLEVBQUUsT0FBTztLQUNiLENBQUMsQ0FBQztJQUVILElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLGdCQUFnQixFQUFFLG1CQUFtQixFQUFFO1FBQzdELElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywyQ0FBMkMsQ0FBQztRQUNyRSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsMENBQTBDLENBQUM7UUFDcEUsS0FBSyxFQUFFLE9BQU87UUFDZCxNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLE9BQU87S0FDYixDQUFDLENBQUM7SUFFSCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxtQkFBbUIsRUFBRTtRQUM3RCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsMkNBQTJDLENBQUM7UUFDckUsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLDBDQUEwQyxDQUFDO1FBQ3BFLEtBQUssRUFBRSxPQUFPO1FBQ2QsTUFBTSxFQUFFLElBQUk7UUFDWixPQUFPLEVBQUUsSUFBSTtRQUNiLElBQUksRUFBRSxPQUFPO0tBQ2IsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFFSCwrRUFBK0U7QUFDL0UsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7O1FBRW5CLE1BQU0sYUFBYSxDQUFDO1lBQ25CLGFBQWE7WUFDYixjQUFjO1lBQ2Qsa0JBQWtCO1NBQ2xCLENBQUMsQ0FBQTtRQUVGLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsbUJBQW1CLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxDQUFDLEVBQUU7WUFDckYsb0JBQW9CLEVBQUUsQ0FBQztTQUN2QjtRQUNELE1BQU0sbUJBQW1CLEVBQUUsQ0FBQztRQUM1QixJQUFJLE1BQU0sRUFBRTtZQUNYLDRCQUE0QjtZQUM1QixNQUFNLENBQUMsRUFBRSxDQUFDLHVCQUF1QixFQUFFLENBQU8sSUFBd0IsRUFBRSxFQUFFOztnQkFDckUsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLE9BQU8sRUFBRTtvQkFDNUIsdUJBQXVCLENBQUMsTUFBQSxJQUFJLENBQUMsTUFBTSxtQ0FBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLENBQUM7aUJBQ2pHO3FCQUNJLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxRQUFRLEVBQUU7b0JBQ2xDLE1BQU0sb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2pDO3FCQUNJO29CQUNKLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLENBQUMsQ0FBQTtpQkFDaEQ7WUFDRixDQUFDLENBQUEsQ0FBQyxDQUFDO1NBQ0g7SUFDRixDQUFDO0NBQUEsQ0FBQyxDQUFDO0FBR0gsa0NBQWtDO0FBQ2xDLEtBQUssQ0FBQyxFQUFFLENBQUMsZUFBZSxFQUFFOztRQUN6QixNQUFNLGFBQWEsRUFBRSxDQUFDO0lBRXZCLENBQUM7Q0FBQSxDQUFDLENBQUM7QUFFSCx1Q0FBdUM7QUFDdkMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRTs7UUFDNUIsTUFBTSxtQkFBbUIsRUFBRSxDQUFDO0lBQzdCLENBQUM7Q0FBQSxDQUFDLENBQUM7QUFFSDs7Ozs7R0FLRztBQUNILEtBQUssQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLEVBQUUsVUFBZ0IsVUFBa0IsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsb0NBQW9DLENBQUMsRUFBRSxLQUFjOztRQUNwSSxNQUFNLGNBQWMsQ0FBQyxPQUFPLEVBQUUsS0FBSyxhQUFMLEtBQUssY0FBTCxLQUFLLEdBQUksd0JBQXdCLEVBQUUsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7Q0FBQSxDQUFDLENBQUM7QUFFSDs7OztHQUlHO0FBQ0gsU0FBUyxvQkFBb0IsQ0FBQyxVQUFrQixJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVE7SUFDbEUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFO1FBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUMvRCxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBQ3RCLENBQUMsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDO0FBRUQ7O0dBRUc7QUFDSCxTQUFlLGFBQWE7O1FBQzNCLHFEQUFxRDtRQUNyRCxNQUFNLFFBQVEsR0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLDJCQUEyQixDQUFDLENBQUM7UUFFOUksTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLE1BQU0sY0FBYyxDQUFDLGNBQWMsRUFBRTtZQUN6RCxRQUFRLEVBQUUsUUFBUTtTQUNsQixDQUFDLENBQUMsQ0FBQztRQUVKLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxNQUFNLGNBQWMsQ0FBQyxhQUFhLEVBQUU7WUFDdkQsUUFBUSxFQUFFLFFBQVE7U0FDbEIsQ0FBQyxDQUFDLENBQUM7UUFDSixNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFDNUQsTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQy9ELE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDeEYsTUFBTSxrQkFBa0IsR0FBRyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUUxRiw0REFBNEQ7UUFDNUQsSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQ3pCLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDOUIsTUFBTSxDQUFDLDRCQUE0QixDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1NBQ3BFO1FBRUQsMkRBQTJEO1FBQzNELElBQUksQ0FBQyxrQkFBa0IsRUFBRTtZQUN4QixTQUFTLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzVCLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztTQUNuRTtRQUVEOzs7V0FHRztRQUNILFNBQVMsaUJBQWlCLENBQUMsS0FBd0I7WUFDbEQsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3ZCLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssQ0FBQyxFQUFFO2dCQUFFLGVBQWUsRUFBRSxDQUFDO2FBQUU7aUJBQzNDO2dCQUFFLHlCQUF5QixFQUFFLENBQUM7YUFBRTtRQUN0QyxDQUFDO0lBQ0YsQ0FBQztDQUFBO0FBRUQ7O0dBRUc7QUFDSCxTQUFTLGVBQWU7SUFDdkIsTUFBTSxPQUFPLEdBQUc7UUFDZixLQUFLLEVBQUU7WUFDTixJQUFJLEVBQUUsOEJBQThCO1lBQ3BDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQ0FBZ0MsQ0FBQztZQUMzRCxRQUFRLEVBQUUscUJBQXFCO1NBQy9CO1FBQ0QsTUFBTSxFQUFFO1lBQ1AsSUFBSSxFQUFFLHVDQUF1QztZQUM3QyxLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsaUNBQWlDLENBQUM7WUFDNUQsUUFBUSxFQUFFLHlCQUF5QjtTQUVuQztLQUNELENBQUM7SUFDRixJQUFJLE1BQU0sQ0FBQztRQUNWLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQztRQUNyRCxPQUFPLEVBQUUsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxNQUFNO1FBQ3JFLE9BQU8sRUFBRSxPQUFPO1FBQ2hCLE9BQU8sRUFBRSxPQUFPO0tBQ2hCLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakIsQ0FBQztBQUVEOztHQUVHO0FBQ0gsU0FBUyxxQkFBcUI7SUFDN0IsS0FBSyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ2pDLENBQUM7QUFFRDs7OztHQUlHO0FBQ0gsU0FBZSxjQUFjLENBQUMsVUFBa0IsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsb0NBQW9DLENBQUMsRUFBRSxLQUFhOztRQUN0SCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQzdFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzdCO1FBQ0QsTUFBTSxJQUFJLEdBQUcsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQztRQUNsRCxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM1QixJQUFJLE1BQU0sRUFBRTtZQUNYLE1BQU0sQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDM0M7UUFDRCx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNqQyxNQUFNLG1CQUFtQixFQUFFLENBQUM7UUFFNUIsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSwwQkFBMEIsQ0FBQyxFQUFFO1lBQ3BFLHVIQUF1SDtZQUN2SCx3QkFBd0IsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFO2dCQUNqRCxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQ3RDLENBQUMsQ0FBQyxDQUFDO1lBRUgsS0FBSyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSxPQUFPLENBQUMsQ0FBQTtTQUM1QztJQUNGLENBQUM7Q0FBQTtBQUVEOzs7R0FHRztBQUNILFNBQVMsd0JBQXdCO0lBQ2hDLE1BQU0sWUFBWSxHQUFXLEVBQUUsQ0FBQztJQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFVLEVBQUUsRUFBRTtRQUMxQyxNQUFNLEtBQUssR0FBVSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQTtRQUN2QyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFvQixFQUFFLEVBQUU7WUFDbEQsNERBQTREO1lBQzVELE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBRTdFLDJEQUEyRDtZQUMzRCxJQUFJLGdCQUFnQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNwRSxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3hCO1FBQ0YsQ0FBQyxDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsQ0FBQztJQUNILE9BQU8sWUFBWSxDQUFDO0FBQ3JCLENBQUM7QUFFRDs7R0FFRztBQUNILFNBQVMseUJBQXlCOztJQUNqQyxNQUFNLElBQUksR0FBdUIsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQUEsSUFBSSxDQUFDLE1BQU0sbUNBQUksRUFBRSxFQUFFLENBQUM7SUFDL0YsTUFBTSxPQUFPLEdBQUc7UUFDZixHQUFHLEVBQUU7WUFDSixJQUFJLEVBQUUsOEJBQThCO1lBQ3BDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQztZQUNuRCxRQUFRLEVBQUUsR0FBUyxFQUFFLGdEQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUMsTUFBTSxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sOEJBQThCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7U0FDdkg7UUFDRCxFQUFFLEVBQUU7WUFDSCxJQUFJLEVBQUUsOEJBQThCO1lBQ3BDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQztZQUN0RCxRQUFRLEVBQUUsR0FBUyxFQUFFLGdEQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsTUFBTSxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sOEJBQThCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7U0FDeEg7S0FDRCxDQUFDO0lBRUYsSUFBSSxNQUFNLENBQUM7UUFDVixLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsb0NBQW9DLENBQUM7UUFDL0QsT0FBTyxFQUFFLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsc0NBQXNDLENBQUMsTUFBTTtRQUMvRSxPQUFPLEVBQUUsT0FBTztRQUNoQixPQUFPLEVBQUUsS0FBSztLQUNkLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakIsQ0FBQztBQUVELEdBQUc7QUFDSDs7OztHQUlHO0FBQ0gsU0FBUyx1QkFBdUIsQ0FBQyxPQUFlOztJQUMvQyxNQUFNLElBQUksR0FBdUIsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQUEsSUFBSSxDQUFDLE1BQU0sbUNBQUksRUFBRSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQztJQUNoSCxNQUFNLE9BQU8sR0FBRztRQUNmLEdBQUcsRUFBRTtZQUNKLElBQUksRUFBRSw4QkFBOEI7WUFDcEMsS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHdCQUF3QixDQUFDO1lBQ25ELFFBQVEsRUFBRSxHQUFTLEVBQUUsZ0RBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsQ0FBQyxNQUFNLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSw0QkFBNEIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtTQUNySDtLQUNELENBQUM7SUFFRixJQUFJLE1BQU0sQ0FBQztRQUNWLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxrQ0FBa0MsQ0FBQztRQUM3RCxPQUFPLEVBQUUsTUFBTSxJQUFJLENBQUMsTUFBTSxNQUFNO1FBQ2hDLE9BQU8sRUFBRSxPQUFPO1FBQ2hCLE9BQU8sRUFBRSxLQUFLO0tBQ2QsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqQixDQUFDO0FBRUQ7OztHQUdHO0FBQ0gsU0FBZSxpQkFBaUIsQ0FBQyxJQUF3Qjs7UUFDeEQsOEdBQThHO1FBQzlHLHFHQUFxRztRQUNyRyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDekIsTUFBTSxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNqQzthQUFNLElBQUksTUFBTSxFQUFFO1lBQ2xCLE1BQU0sQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDM0M7SUFDRixDQUFDO0NBQUE7QUFFRDs7O0dBR0c7QUFDSCxTQUFlLG9CQUFvQixDQUFDLElBQXdCOztRQUMzRCxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDekIsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBVSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2RixJQUFJLFlBQVksRUFBRTtnQkFDakIsTUFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3BFLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ3BCLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztnQkFDakIsSUFBSSxvQkFBb0IsRUFBRSxFQUFFO29CQUMzQix1REFBdUQ7b0JBQ3ZELElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsbUJBQW1CLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO3dCQUM1RSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDOUI7b0JBRUQsTUFBTSxZQUFZLEdBQUcsd0JBQXdCLEVBQUUsQ0FBQztvQkFDaEQsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSwwQkFBMEIsQ0FBQzsyQkFDL0QsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssWUFBWSxDQUFDLEVBQUUsQ0FBQyxFQUN4RDt3QkFDRCxnSEFBZ0g7d0JBQ2hILElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFOzRCQUMxQyxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLHFCQUFxQixDQUFZLENBQUM7NEJBQ3pGLElBQUksVUFBVSxFQUFFO2dDQUNmLE9BQU8sSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQzs2QkFDNUI7d0JBQ0YsQ0FBQyxDQUFDLENBQUM7d0JBQ0gsbUVBQW1FO3dCQUNuRSxPQUFPLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsNEJBQTRCLENBQUMsQ0FBQzt3QkFFNUQsS0FBSyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSxPQUFPLENBQUMsQ0FBQztxQkFDN0M7aUJBQ0Q7YUFDRDtpQkFBTTtnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLHdCQUF3QixJQUFJLENBQUMsTUFBTSxpQkFBaUIsQ0FBQyxDQUFDO2FBQ3BFO1NBQ0Q7SUFDRixDQUFDO0NBQUE7QUFFRDs7O0dBR0c7QUFDSCxTQUFTLG9CQUFvQjtJQUM1QixJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUM7SUFDdEIsTUFBTSxVQUFVLEdBQUcsd0JBQXdCLEVBQUUsQ0FBQztJQUM5QyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBVSxFQUFFLEVBQUU7UUFDakMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxDQUFDLEVBQUU7WUFDL0MsVUFBVSxHQUFHLEtBQUssQ0FBQztTQUNuQjtJQUNGLENBQUMsQ0FBQyxDQUFDO0lBQ0gsT0FBTyxVQUFVLENBQUM7QUFDbkIsQ0FBQztBQUdEOzs7O0dBSUc7QUFDSCxTQUFlLDRCQUE0QixDQUFDLElBQXdCOztRQUNuRSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLDJCQUEyQixDQUFDLEVBQUU7WUFDckUsd0JBQXdCO1lBQ3hCLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzVGLElBQUksV0FBVyxFQUFFO2dCQUNoQixNQUFNLFFBQVEsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDdkMsTUFBTSxPQUFPLEdBQUcsR0FBRyxRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsMEJBQTBCLENBQUMsRUFBRSxDQUFDO2dCQUNoRixNQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLEVBQUUsRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFFLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7YUFDcEY7aUJBQU07Z0JBQ04sTUFBTSxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsSUFBSSxDQUFDLE1BQU0saUJBQWlCLENBQUMsQ0FBQzthQUN0RTtTQUNEO0lBQ0YsQ0FBQztDQUFBO0FBR0Q7OztHQUdHO0FBQ0gsU0FBZSw4QkFBOEIsQ0FBQyxJQUF3Qjs7UUFDckUsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxnQ0FBZ0MsQ0FBQyxFQUFFO1lBQzFFLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQVUsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDdEYsSUFBSSxXQUFXLEVBQUU7Z0JBQ2hCLE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2dCQUN2QyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO2dCQUMzSCxNQUFNLE9BQU8sR0FBRyxHQUFHLFFBQVEsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQywrQkFBK0IsQ0FBQyxJQUFJLE1BQU0sRUFBRSxDQUFDO2dCQUMvRixNQUFNLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLEVBQUUsRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFFLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7YUFDcEY7aUJBQU07Z0JBQ04sTUFBTSxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsSUFBSSxDQUFDLE1BQU0saUJBQWlCLENBQUMsQ0FBQzthQUN0RTtTQUNEO0lBQ0YsQ0FBQztDQUFBO0FBRUQ7O0dBRUc7QUFDSCxTQUFlLG1CQUFtQjs7UUFDakMsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztRQUMzRSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO1FBQzlFLElBQUksU0FBUyxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQzdCLE1BQU0sV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxnREFBZ0QsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ2hJO2FBQU0sSUFBSSxTQUFTLElBQUksVUFBVSxFQUFFO1lBQ25DLE1BQU0sV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxVQUFvQixFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDcEc7SUFDRixDQUFDO0NBQUE7QUFFRDs7R0FFRztBQUNILFNBQWUsbUJBQW1COztRQUNqQyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQTtRQUNyQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMxQyxvQkFBb0I7WUFDcEIsTUFBTSxLQUFLLEdBQUcsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3RFLDZCQUE2QjtZQUM3QixNQUFNLE1BQU0sR0FBVyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUU3QyxvQ0FBb0M7WUFDcEMsTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsTUFBTSwwQkFBMEIsQ0FBQyxDQUFDO1lBQ3hGLE1BQU0sZUFBZSxHQUFHLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1lBRTdDLElBQUksS0FBYSxDQUFBO1lBQ2pCLElBQUksVUFBVSxFQUFFLGFBQWEsRUFBRSxjQUFjLEVBQUUsaUJBQWlCLENBQUM7WUFFakUsSUFBSSxLQUFLLEVBQUU7Z0JBQ1YsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHdCQUF3QixDQUFDLENBQUM7Z0JBQ3JELFVBQVUsR0FBRyxPQUFPLENBQUM7Z0JBQ3JCLGFBQWEsR0FBRyxXQUFXLENBQUM7Z0JBQzVCLGNBQWMsR0FBRyxVQUFVLENBQUM7Z0JBQzVCLGlCQUFpQixHQUFHLFVBQVUsQ0FBQzthQUMvQjtpQkFBTTtnQkFDTixLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsMkJBQTJCLENBQUMsQ0FBQztnQkFDeEQsVUFBVSxHQUFHLFdBQVcsQ0FBQztnQkFDekIsYUFBYSxHQUFHLE9BQU8sQ0FBQztnQkFDeEIsY0FBYyxHQUFHLFVBQVUsQ0FBQztnQkFDNUIsaUJBQWlCLEdBQUcsVUFBVSxDQUFDO2FBQy9CO1lBRUQsSUFBSSxlQUFlLEVBQUU7Z0JBQ3BCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQ3hDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsaUJBQWlCLENBQUMsQ0FBQztnQkFDNUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDbEMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUN0QztpQkFBTTtnQkFDTix5QkFBeUI7Z0JBQ3pCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FDekQsTUFBTSxjQUFjLENBQUMsa0JBQWtCLEVBQUU7b0JBQ3hDLGNBQWMsRUFBRSxjQUFjO29CQUM5QixVQUFVLEVBQUUsVUFBVTtvQkFDdEIsS0FBSyxFQUFFLEtBQUs7aUJBQ1osQ0FBQyxDQUNGLENBQUM7YUFDRjtTQUNEO0lBQ0YsQ0FBQztDQUFBO0FBRUQsU0FBUyxTQUFTLENBQUMsSUFBVTtJQUM1QixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBRSxTQUFTLENBQUMsQ0FBQztJQUN2RSxPQUFPLElBQUksQ0FBQyxFQUFFLEtBQUssU0FBUyxDQUFDO0FBQzlCLENBQUM7QUFDRDs7R0FFRztBQUNILE1BQU0sa0JBQWtCO0lBQXhCO1FBQ0MsV0FBTSxHQUFHLEVBQUUsQ0FBQztRQUNaLFVBQUssR0FBRyxLQUFLLENBQUM7UUFDZCxXQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ1osV0FBTSxHQUFHLEVBQUUsQ0FBQztJQUNiLENBQUM7Q0FBQSIsImZpbGUiOiJyZWFkeS1jaGVjay5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9hd2FpdC10aGVuYWJsZSAqL1xyXG4vKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvcmVzdHJpY3QtdGVtcGxhdGUtZXhwcmVzc2lvbnMgKi9cclxuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1hcmd1bWVudCAqL1xyXG4vKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLWNhbGwgKi9cclxuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1tZW1iZXItYWNjZXNzICovXHJcbi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtYXNzaWdubWVudCAqL1xyXG5cclxuY29uc3QgcG9wb3V0QnRuRmlsZSA9ICdtb2R1bGVzL21nLXJlYWR5LWNoZWNrL2hhbmRsZWJhcnMvcG9wb3V0QnRuLmhicyc7XHJcbmNvbnN0IHNpZGViYXJCdG5GaWxlID0gJ21vZHVsZXMvbWctcmVhZHktY2hlY2svaGFuZGxlYmFycy9zaWRlYmFyQnRuLmhicyc7XHJcbmNvbnN0IHJlYWR5SW5kaWNhdG9yRmlsZSA9ICdtb2R1bGVzL21nLXJlYWR5LWNoZWNrL2hhbmRsZWJhcnMvcmVhZHlJbmRpY2F0b3IuaGJzJztcclxuLyoqXHJcbiAqIFJlZ2lzdGVyIGFsbCBzZXR0aW5nc1xyXG4gKi9cclxuSG9va3Mub25jZShcImluaXRcIiwgZnVuY3Rpb24gKCkge1xyXG5cclxuXHRnYW1lLnNldHRpbmdzLnJlZ2lzdGVyKFwibWctcmVhZHktY2hlY2tcIiwgXCJzaG93Q2hhdE1lc3NhZ2VzRm9yVXNlclVwZGF0ZXNcIiwge1xyXG5cdFx0bmFtZTogZ2FtZS5pMThuLmxvY2FsaXplKFwiUkVBRFlDSEVDSy5TZXR0aW5nc0NoYXRNZXNzYWdlc0ZvclVzZXJVcGRhdGVzVGl0bGVcIiksXHJcblx0XHRoaW50OiBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLlNldHRpbmdzQ2hhdE1lc3NhZ2VzRm9yVXNlclVwZGF0ZXNIaW50XCIpLFxyXG5cdFx0c2NvcGU6IFwid29ybGRcIixcclxuXHRcdGNvbmZpZzogdHJ1ZSxcclxuXHRcdGRlZmF1bHQ6IHRydWUsXHJcblx0XHR0eXBlOiBCb29sZWFuXHJcblx0fSk7XHJcblxyXG5cdGdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJtZy1yZWFkeS1jaGVja1wiLCBcInNob3dDaGF0TWVzc2FnZXNGb3JDaGVja3NcIiwge1xyXG5cdFx0bmFtZTogZ2FtZS5pMThuLmxvY2FsaXplKFwiUkVBRFlDSEVDSy5TZXR0aW5nc0NoYXRNZXNzYWdlc0ZvckNoZWNrc1RpdGxlXCIpLFxyXG5cdFx0aGludDogZ2FtZS5pMThuLmxvY2FsaXplKFwiUkVBRFlDSEVDSy5TZXR0aW5nc0NoYXRNZXNzYWdlc0ZvckNoZWNrc0hpbnRcIiksXHJcblx0XHRzY29wZTogXCJ3b3JsZFwiLFxyXG5cdFx0Y29uZmlnOiB0cnVlLFxyXG5cdFx0ZGVmYXVsdDogZmFsc2UsXHJcblx0XHR0eXBlOiBCb29sZWFuXHJcblx0fSk7XHJcblxyXG5cdGdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJtZy1yZWFkeS1jaGVja1wiLCBcInBsYXlBbGVydEZvckNoZWNrXCIsIHtcclxuXHRcdG5hbWU6IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suU2V0dGluZ3NQbGF5QWxlcnRGb3JDaGVja3NUaXRsZVwiKSxcclxuXHRcdGhpbnQ6IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suU2V0dGluZ3NQbGF5QWxlcnRGb3JDaGVja3NIaW50XCIpLFxyXG5cdFx0c2NvcGU6IFwid29ybGRcIixcclxuXHRcdGNvbmZpZzogdHJ1ZSxcclxuXHRcdGRlZmF1bHQ6IGZhbHNlLFxyXG5cdFx0dHlwZTogQm9vbGVhblxyXG5cdH0pO1xyXG5cclxuXHRnYW1lLnNldHRpbmdzLnJlZ2lzdGVyKFwibWctcmVhZHktY2hlY2tcIiwgXCJjaGVja0FsZXJ0U291bmRQYXRoXCIsIHtcclxuXHRcdG5hbWU6IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suU2V0dGluZ3NDaGVja0FsZXJ0U291bmRQYXRoVGl0bGVcIiksXHJcblx0XHRoaW50OiBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLlNldHRpbmdzQ2hlY2tBbGVydFNvdW5kUGF0aEhpbnRcIiksXHJcblx0XHRzY29wZTogXCJ3b3JsZFwiLFxyXG5cdFx0Y29uZmlnOiB0cnVlLFxyXG5cdFx0ZGVmYXVsdDogJ21vZHVsZXMvbWctcmVhZHktY2hlY2svc291bmRzL25vdGlmaWNhdGlvbi5tcDMnLFxyXG5cdFx0dHlwZTogU3RyaW5nXHJcblx0fSk7XHJcblxyXG5cdGdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJtZy1yZWFkeS1jaGVja1wiLCBcImVuYWJsZURpc2NvcmRJbnRlZ3JhdGlvblwiLCB7XHJcblx0XHRuYW1lOiBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLlNldHRpbmdzRW5hYmxlRGlzY29yZEludGVncmF0aW9uVGl0bGVcIiksXHJcblx0XHRoaW50OiBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLlNldHRpbmdzRW5hYmxlRGlzY29yZEludGVncmF0aW9uSGludFwiKSxcclxuXHRcdHNjb3BlOiBcIndvcmxkXCIsXHJcblx0XHRjb25maWc6IHRydWUsXHJcblx0XHRkZWZhdWx0OiBmYWxzZSxcclxuXHRcdHR5cGU6IEJvb2xlYW5cclxuXHR9KTtcclxuXHJcblx0Z2FtZS5zZXR0aW5ncy5yZWdpc3RlcihcIm1nLXJlYWR5LWNoZWNrXCIsIFwic3RhdHVzUmVzZXRPbkxvYWRcIiwge1xyXG5cdFx0bmFtZTogZ2FtZS5pMThuLmxvY2FsaXplKFwiUkVBRFlDSEVDSy5TZXR0aW5nc1N0YXR1c1Jlc2V0T25Mb2FkVGl0bGVcIiksXHJcblx0XHRoaW50OiBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLlNldHRpbmdzU3RhdHVzUmVzZXRPbkxvYWRIaW50XCIpLFxyXG5cdFx0c2NvcGU6IFwid29ybGRcIixcclxuXHRcdGNvbmZpZzogdHJ1ZSxcclxuXHRcdGRlZmF1bHQ6IHRydWUsXHJcblx0XHR0eXBlOiBCb29sZWFuXHJcblx0fSk7XHJcblxyXG5cdGdhbWUuc2V0dGluZ3MucmVnaXN0ZXIoXCJtZy1yZWFkeS1jaGVja1wiLCBcInBhdXNlT25SZWFkeUNoZWNrXCIsIHtcclxuXHRcdG5hbWU6IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suU2V0dGluZ3NQYXVzZU9uUmVhZHlDaGVja1RpdGxlXCIpLFxyXG5cdFx0aGludDogZ2FtZS5pMThuLmxvY2FsaXplKFwiUkVBRFlDSEVDSy5TZXR0aW5nc1BhdXNlT25SZWFkeUNoZWNrSGludFwiKSxcclxuXHRcdHNjb3BlOiBcIndvcmxkXCIsXHJcblx0XHRjb25maWc6IHRydWUsXHJcblx0XHRkZWZhdWx0OiB0cnVlLFxyXG5cdFx0dHlwZTogQm9vbGVhblxyXG5cdH0pO1xyXG5cclxuXHRnYW1lLnNldHRpbmdzLnJlZ2lzdGVyKFwibWctcmVhZHktY2hlY2tcIiwgXCJ1bnBhdXNlT25BbGxSZWFkeVwiLCB7XHJcblx0XHRuYW1lOiBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLlNldHRpbmdzVW5wYXVzZU9uQWxsUmVhZHlUaXRsZVwiKSxcclxuXHRcdGhpbnQ6IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suU2V0dGluZ3NVbnBhdXNlT25BbGxSZWFkeUhpbnRcIiksXHJcblx0XHRzY29wZTogXCJ3b3JsZFwiLFxyXG5cdFx0Y29uZmlnOiB0cnVlLFxyXG5cdFx0ZGVmYXVsdDogdHJ1ZSxcclxuXHRcdHR5cGU6IEJvb2xlYW5cclxuXHR9KTtcclxufSk7XHJcblxyXG4vLyBSZW5kZXIgdGhlIHN0YXR1cyBzeW1ib2xzIGFuZCBpZiB0aGUgc2V0dGluZyBpcyBlbmFibGVkLCByZXNldCBhbGwgc3RhdHVzZXMuXHJcbkhvb2tzLm9uY2UoXCJyZWFkeVwiLCBhc3luYyBmdW5jdGlvbiAoKSB7XHJcblxyXG5cdGF3YWl0IGxvYWRUZW1wbGF0ZXMoW1xyXG5cdFx0cG9wb3V0QnRuRmlsZSxcclxuXHRcdHNpZGViYXJCdG5GaWxlLFxyXG5cdFx0cmVhZHlJbmRpY2F0b3JGaWxlXHJcblx0XSlcclxuXHJcblx0aWYgKGdhbWUuc2V0dGluZ3MuZ2V0KCdtZy1yZWFkeS1jaGVjaycsICdzdGF0dXNSZXNldE9uTG9hZCcpICYmIGdhbWUudXNlci5yb2xlID09PSA0KSB7XHJcblx0XHRzZXRQbGF5ZXJzVG9Ob3RSZWFkeSgpO1xyXG5cdH1cclxuXHRhd2FpdCB1cGRhdGVQbGF5ZXJzV2luZG93KCk7XHJcblx0aWYgKHNvY2tldCkge1xyXG5cdFx0Ly8gY3JlYXRlIHRoZSBzb2NrZXQgaGFuZGxlclxyXG5cdFx0c29ja2V0Lm9uKCdtb2R1bGUubWctcmVhZHktY2hlY2snLCBhc3luYyAoZGF0YTogUmVhZHlDaGVja1VzZXJEYXRhKSA9PiB7XHJcblx0XHRcdGlmIChkYXRhLmFjdGlvbiA9PT0gJ2NoZWNrJykge1xyXG5cdFx0XHRcdGRpc3BsYXlSZWFkeUNoZWNrRGlhbG9nKGRhdGEuZGlhbG9nID8/IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suRGlhbG9nQ29udGVudFJlYWR5Q2hlY2tcIikpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2UgaWYgKGRhdGEuYWN0aW9uID09PSAndXBkYXRlJykge1xyXG5cdFx0XHRcdGF3YWl0IHByb2Nlc3NSZWFkeVJlc3BvbnNlKGRhdGEpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGVsc2Uge1xyXG5cdFx0XHRcdGNvbnNvbGUuZXJyb3IoXCJVbnJlY29nbml6ZWQgcmVhZHkgY2hlY2sgYWN0aW9uXCIpXHJcblx0XHRcdH1cclxuXHRcdH0pO1xyXG5cdH1cclxufSk7XHJcblxyXG5cclxuLy8gU2V0IFVwIEJ1dHRvbnMgYW5kIFNvY2tldCBTdHVmZlxyXG5Ib29rcy5vbigncmVuZGVyQ2hhdExvZycsIGFzeW5jIGZ1bmN0aW9uICgpIHtcclxuXHRhd2FpdCBjcmVhdGVCdXR0b25zKCk7XHJcblxyXG59KTtcclxuXHJcbi8vIFVwZGF0ZSB0aGUgZGlzcGxheSBvZiB0aGUgUGxheWVyIFVJLlxyXG5Ib29rcy5vbigncmVuZGVyUGxheWVyTGlzdCcsIGFzeW5jIGZ1bmN0aW9uICgpIHtcclxuXHRhd2FpdCB1cGRhdGVQbGF5ZXJzV2luZG93KCk7XHJcbn0pO1xyXG5cclxuLyoqXHJcbiAqIEluaXRpYXRlIGEgcmVhZHkgY2hlY2tcclxuICogXHJcbiAqIEBwYXJhbSBtZXNzYWdlIFRoZSBwcm9tcHQgdG8gZGlzcGxheSBmb3IgdGhlIHJlYWR5IGNoZWNrXHJcbiAqIEBwYXJhbSB1c2VycyBUaGUgdXNlcnMgdG8gaW5jbHVkZSBpbiB0aGUgcmVhZHkgY2hlY2suIERlZmF1bHRzIHRvIGFsbCBVc2Vycy5cclxuICovXHJcbkhvb2tzLm9uKCdpbml0UmVhZHlDaGVjaycsIGFzeW5jIGZ1bmN0aW9uIChtZXNzYWdlOiBzdHJpbmcgPSBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLkRpYWxvZ0NvbnRlbnRSZWFkeUNoZWNrXCIpLCB1c2Vycz86IFVzZXJbXSkge1xyXG5cdGF3YWl0IGluaXRSZWFkeUNoZWNrKG1lc3NhZ2UsIHVzZXJzID8/IGdldFVzZXJzV2l0aFRva2VuSW5TY2VuZSgpKTtcclxufSk7XHJcblxyXG4vKipcclxuICogU2V0IHRoZSBzdGF0dXMgb2YgY2VydGFpbiBwbGF5ZXJzIHRvIFwiTm90IFJlYWR5XCJcclxuICogXHJcbiAqIEBwYXJhbSBwbGF5ZXJzIFRoZSBwbGF5ZXJzIHRvIHNldCBzdGF0dXMgdG8gXCJOb3QgUmVhZHlcIlxyXG4gKi9cclxuZnVuY3Rpb24gc2V0UGxheWVyc1RvTm90UmVhZHkocGxheWVyczogVXNlcltdID0gZ2FtZS51c2Vycy5jb250ZW50cykge1xyXG5cdHBsYXllcnMuZm9yRWFjaCgodXNlcjogVXNlcikgPT4ge1xyXG5cdFx0dXNlci5zZXRGbGFnKCdtZy1yZWFkeS1jaGVjaycsICdpc1JlYWR5JywgZmFsc2UpLmNhdGNoKHJlYXNvbiA9PiB7XHJcblx0XHRcdGNvbnNvbGUuZXJyb3IocmVhc29uKVxyXG5cdFx0fSk7XHJcblx0fSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDcmVhdGUgdGhlIHJlYWR5IGNoZWNrIGJ1dHRvbnNcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUJ1dHRvbnMoKSB7XHJcblx0Ly9zZXQgdGl0bGUgYmFzZWQgb24gd2hldGhlciB0aGUgdXNlciBpcyBwbGF5ZXIgb3IgR01cclxuXHRjb25zdCBidG5UaXRsZTogc3RyaW5nID0gZ2FtZS51c2VyLnJvbGUgPT09IDQgPyBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLlVpR21CdXR0b25cIikgOiBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLlVpQ2hhbmdlQnV0dG9uXCIpO1xyXG5cclxuXHRjb25zdCBzaWRlYmFyQnRuID0gJChhd2FpdCByZW5kZXJUZW1wbGF0ZShzaWRlYmFyQnRuRmlsZSwge1xyXG5cdFx0YnRuVGl0bGU6IGJ0blRpdGxlXHJcblx0fSkpO1xyXG5cclxuXHRjb25zdCBwb3BvdXRCdG4gPSAkKGF3YWl0IHJlbmRlclRlbXBsYXRlKHBvcG91dEJ0bkZpbGUsIHtcclxuXHRcdGJ0blRpdGxlOiBidG5UaXRsZVxyXG5cdH0pKTtcclxuXHRjb25zdCBzaWRlYmFyRGl2ID0gJChcIiNzaWRlYmFyXCIpLmZpbmQoXCIuY2hhdC1jb250cm9sLWljb25cIik7XHJcblx0Y29uc3QgcG9wb3V0RGl2ID0gJChcIiNjaGF0LXBvcG91dFwiKS5maW5kKFwiLmNoYXQtY29udHJvbC1pY29uXCIpO1xyXG5cdGNvbnN0IGJ0bkFscmVhZHlJblNpZGViYXIgPSAkKFwiI3NpZGViYXJcIikuZmluZChcIi5jcmFzaC1yZWFkeS1jaGVjay1zaWRlYmFyXCIpLmxlbmd0aCA+IDA7XHJcblx0Y29uc3QgYnRuQWxyZWFkeUluUG9wb3V0ID0gJChcIiNjaGF0LXBvcG91dFwiKS5maW5kKFwiLmNyYXNoLXJlYWR5LWNoZWNrLXBvcG91dFwiKS5sZW5ndGggPiAwO1xyXG5cclxuXHQvLyBBZGQgdGhlIGJ1dHRvbiB0byB0aGUgc2lkZWJhciBpZiBpdCBkb2Vzbid0IGFscmVhZHkgZXhpc3RcclxuXHRpZiAoIWJ0bkFscmVhZHlJblNpZGViYXIpIHtcclxuXHRcdHNpZGViYXJEaXYuYmVmb3JlKHNpZGViYXJCdG4pO1xyXG5cdFx0alF1ZXJ5KFwiLmNyYXNoLXJlYWR5LWNoZWNrLXNpZGViYXJcIikub24oXCJjbGlja1wiLCByZWFkeUNoZWNrT25DbGljayk7XHJcblx0fVxyXG5cclxuXHQvLyBBZGQgdGhlIGJ1dHRvbiB0byB0aGUgcG9wb3V0IGlmIGl0IGRvZXNuJ3QgYWxyZWFkeSBleGlzdFxyXG5cdGlmICghYnRuQWxyZWFkeUluUG9wb3V0KSB7XHJcblx0XHRwb3BvdXREaXYuYmVmb3JlKHBvcG91dEJ0bik7XHJcblx0XHRqUXVlcnkoXCIuY3Jhc2gtcmVhZHktY2hlY2stcG9wb3V0XCIpLm9uKFwiY2xpY2tcIiwgcmVhZHlDaGVja09uQ2xpY2spO1xyXG5cdH1cclxuXHJcblx0LyoqXHJcblx0ICogUmVhZHkgY2hlY2sgYnV0dG9uIGxpc3RlbmVyXHJcblx0ICogQHBhcmFtIGV2ZW50IHRoZSBidXR0b24gY2xpY2sgZXZlbnRcclxuXHQgKi9cclxuXHRmdW5jdGlvbiByZWFkeUNoZWNrT25DbGljayhldmVudDogSlF1ZXJ5LkNsaWNrRXZlbnQpIHtcclxuXHRcdGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcblx0XHRpZiAoZ2FtZS51c2VyLnJvbGUgPT09IDQpIHsgZGlzcGxheUdtRGlhbG9nKCk7IH1cclxuXHRcdGVsc2UgeyBkaXNwbGF5U3RhdHVzVXBkYXRlRGlhbG9nKCk7IH1cclxuXHR9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBEaXNwbGF5IHRoZSBkaWFsb2d1ZSBwcm9tcHRpbmcgdGhlIEdNIHRvIGVpdGhlciBzdGFydCByZWFkeSBjaGVjayBvciBzZXQgc3RhdHVzLlxyXG4gKi9cclxuZnVuY3Rpb24gZGlzcGxheUdtRGlhbG9nKCkge1xyXG5cdGNvbnN0IGJ1dHRvbnMgPSB7XHJcblx0XHRjaGVjazoge1xyXG5cdFx0XHRpY29uOiBcIjxpIGNsYXNzPSdmYXMgZmEtY2hlY2snPjwvaT5cIixcclxuXHRcdFx0bGFiZWw6IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suR21EaWFsb2dCdXR0b25DaGVja1wiKSxcclxuXHRcdFx0Y2FsbGJhY2s6IGluaXRSZWFkeUNoZWNrRGVmYXVsdFxyXG5cdFx0fSxcclxuXHRcdHN0YXR1czoge1xyXG5cdFx0XHRpY29uOiBcIjxpIGNsYXNzPSdmYXMgZmEtaG91cmdsYXNzLWhhbGYnPjwvaT5cIixcclxuXHRcdFx0bGFiZWw6IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suR21EaWFsb2dCdXR0b25TdGF0dXNcIiksXHJcblx0XHRcdGNhbGxiYWNrOiBkaXNwbGF5U3RhdHVzVXBkYXRlRGlhbG9nXHJcblxyXG5cdFx0fVxyXG5cdH07XHJcblx0bmV3IERpYWxvZyh7XHJcblx0XHR0aXRsZTogZ2FtZS5pMThuLmxvY2FsaXplKFwiUkVBRFlDSEVDSy5HbURpYWxvZ1RpdGxlXCIpLFxyXG5cdFx0Y29udGVudDogYDxwPiR7Z2FtZS5pMThuLmxvY2FsaXplKFwiUkVBRFlDSEVDSy5HbURpYWxvZ0NvbnRlbnRcIil9PC9wPmAsXHJcblx0XHRidXR0b25zOiBidXR0b25zLFxyXG5cdFx0ZGVmYXVsdDogXCJjaGVja1wiXHJcblx0fSkucmVuZGVyKHRydWUpO1xyXG59XHJcblxyXG4vKipcclxuICogY2FsbGJhY2sgZnVuY3Rpb24gZm9yIHRoZSBHTSdzIHJlYWR5IGNoZWNrIGJ1dHRvblxyXG4gKi9cclxuZnVuY3Rpb24gaW5pdFJlYWR5Q2hlY2tEZWZhdWx0KCkge1xyXG5cdEhvb2tzLmNhbGxBbGwoXCJpbml0UmVhZHlDaGVja1wiKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEluaXRpYXRlIHRoZSByZWFkeSBjaGVjaywgbm90aWZ5aW5nIHBsYXllcnMgb3ZlciBkaXNjb3JkIChpZiBzZXR0aW5nIGlzIGVuYWJsZWQpIGFuZCBpbi1nYW1lIHRvIHNldCB0aGVpciByZWFkeSBzdGF0dXMuXHJcbiAqIFxyXG4gKiBAcGFyYW0gbWVzc2FnZSBUaGUgbWVzc2FnZSB0byBkaXNwbGF5IGluIHRoZSByZWFkeSBjaGVjayBkaWFsb2d1ZSBhbmQgdG8gZm9yd2FyZCB0byBEaXNjb3JkXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBpbml0UmVhZHlDaGVjayhtZXNzYWdlOiBzdHJpbmcgPSBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLkRpYWxvZ0NvbnRlbnRSZWFkeUNoZWNrXCIpLCB1c2VyczogVXNlcltdKSB7XHJcblx0aWYgKGdhbWUuc2V0dGluZ3MuZ2V0KCdtZy1yZWFkeS1jaGVjaycsICdwYXVzZU9uUmVhZHlDaGVjaycpICYmICFnYW1lLnBhdXNlZCkge1xyXG5cdFx0Z2FtZS50b2dnbGVQYXVzZSh0cnVlLCB0cnVlKTtcclxuXHR9XHJcblx0Y29uc3QgZGF0YSA9IHsgYWN0aW9uOiAnY2hlY2snLCBkaWFsb2c6IG1lc3NhZ2UgfTtcclxuXHRzZXRQbGF5ZXJzVG9Ob3RSZWFkeSh1c2Vycyk7XHJcblx0aWYgKHNvY2tldCkge1xyXG5cdFx0c29ja2V0LmVtaXQoJ21vZHVsZS5tZy1yZWFkeS1jaGVjaycsIGRhdGEpO1xyXG5cdH1cclxuXHRkaXNwbGF5UmVhZHlDaGVja0RpYWxvZyhtZXNzYWdlKTtcclxuXHRhd2FpdCBwbGF5UmVhZHlDaGVja0FsZXJ0KCk7XHJcblxyXG5cdGlmIChnYW1lLnNldHRpbmdzLmdldCgnbWctcmVhZHktY2hlY2snLCAnZW5hYmxlRGlzY29yZEludGVncmF0aW9uJykpIHtcclxuXHRcdC8vIEZvciBldmVyeSB1c2VyIGluIHRoZSBnYW1lLCBpZiB0aGV5IGhhdmUgYSB0b2tlbiBpbiB0aGUgY3VycmVudCBzY2VuZSwgcGluZyB0aGVtIGFzIHBhcnQgb2YgdGhlIHJlYWR5IGNoZWNrIG1lc3NhZ2UuXHJcblx0XHRnZXRVc2Vyc1dpdGhUb2tlbkluU2NlbmUoKS5mb3JFYWNoKCh1c2VyOiBVc2VyKSA9PiB7XHJcblx0XHRcdG1lc3NhZ2UgPSBgQCR7dXNlci5uYW1lfSAke21lc3NhZ2V9YDtcclxuXHRcdH0pO1xyXG5cclxuXHRcdEhvb2tzLmNhbGxBbGwoXCJzZW5kRGlzY29yZE1lc3NhZ2VcIiwgbWVzc2FnZSlcclxuXHR9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBHZXRzIGFuIGFycmF5IG9mIHVzZXJzIHRoYXQgaGF2ZSBhIHRva2VuIGluIHRoZSBjdXJyZW50IHNjZW5lLlxyXG4gKiBAcmV0dXJucyBUaGUgYXJyYXkgb2YgdXNlcnNcclxuICovXHJcbmZ1bmN0aW9uIGdldFVzZXJzV2l0aFRva2VuSW5TY2VuZSgpOiBVc2VyW10ge1xyXG5cdGNvbnN0IHVzZXJzSW5TY2VuZTogVXNlcltdID0gW107XHJcblx0Z2FtZS51c2Vycy5jb250ZW50cy5mb3JFYWNoKCh1c2VyOiBVc2VyKSA9PiB7XHJcblx0XHRjb25zdCBzY2VuZTogU2NlbmUgPSBnYW1lLnNjZW5lcy5hY3RpdmVcclxuXHRcdHNjZW5lLmRhdGEudG9rZW5zLmZvckVhY2goKHRva2VuOiBUb2tlbkRvY3VtZW50KSA9PiB7XHJcblx0XHRcdC8vIHBlcm1pc3Npb25zIG9iamVjdCB0aGF0IG1hcHMgdXNlciBpZHMgdG8gcGVybWlzc2lvbiBlbnVtc1xyXG5cdFx0XHRjb25zdCB0b2tlblBlcm1pc3Npb25zID0gZ2FtZS5hY3RvcnMuZ2V0KHRva2VuLmRhdGEuYWN0b3JJZCkuZGF0YS5wZXJtaXNzaW9uO1xyXG5cclxuXHRcdFx0Ly8gaWYgdGhlIHVzZXIgb3ducyB0aGlzIHRva2VuLCB0aGVuIHRoZXkgYXJlIGluIHRoZSBzY2VuZS5cclxuXHRcdFx0aWYgKHRva2VuUGVybWlzc2lvbnNbdXNlci5pZF0gPT09IDMgJiYgIXVzZXJzSW5TY2VuZS5pbmNsdWRlcyh1c2VyKSkge1xyXG5cdFx0XHRcdHVzZXJzSW5TY2VuZS5wdXNoKHVzZXIpO1xyXG5cdFx0XHR9XHJcblx0XHR9KTtcclxuXHR9KTtcclxuXHRyZXR1cm4gdXNlcnNJblNjZW5lO1xyXG59XHJcblxyXG4vKipcclxuICogU2V0IHVwIHRoZSBkaWFsb2d1ZSB0byB1cGRhdGUgeW91ciByZWFkeSBzdGF0dXMuXHJcbiAqL1xyXG5mdW5jdGlvbiBkaXNwbGF5U3RhdHVzVXBkYXRlRGlhbG9nKCkge1xyXG5cdGNvbnN0IGRhdGE6IFJlYWR5Q2hlY2tVc2VyRGF0YSA9IHsgYWN0aW9uOiAndXBkYXRlJywgcmVhZHk6IGZhbHNlLCB1c2VySWQ6IGdhbWUudXNlcklkID8/IFwiXCIgfTtcclxuXHRjb25zdCBidXR0b25zID0ge1xyXG5cdFx0eWVzOiB7XHJcblx0XHRcdGljb246IFwiPGkgY2xhc3M9J2ZhcyBmYS1jaGVjayc+PC9pPlwiLFxyXG5cdFx0XHRsYWJlbDogZ2FtZS5pMThuLmxvY2FsaXplKFwiUkVBRFlDSEVDSy5TdGF0dXNSZWFkeVwiKSxcclxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jICgpID0+IHsgZGF0YS5yZWFkeSA9IHRydWU7IGF3YWl0IHVwZGF0ZVJlYWR5U3RhdHVzKGRhdGEpOyBhd2FpdCBkaXNwbGF5U3RhdHVzVXBkYXRlQ2hhdE1lc3NhZ2UoZGF0YSk7IH1cclxuXHRcdH0sXHJcblx0XHRubzoge1xyXG5cdFx0XHRpY29uOiBcIjxpIGNsYXNzPSdmYXMgZmEtdGltZXMnPjwvaT5cIixcclxuXHRcdFx0bGFiZWw6IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suU3RhdHVzTm90UmVhZHlcIiksXHJcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoKSA9PiB7IGRhdGEucmVhZHkgPSBmYWxzZTsgYXdhaXQgdXBkYXRlUmVhZHlTdGF0dXMoZGF0YSk7IGF3YWl0IGRpc3BsYXlTdGF0dXNVcGRhdGVDaGF0TWVzc2FnZShkYXRhKTsgfVxyXG5cdFx0fVxyXG5cdH07XHJcblxyXG5cdG5ldyBEaWFsb2coe1xyXG5cdFx0dGl0bGU6IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suRGlhbG9nVGl0bGVTdGF0dXNVcGRhdGVcIiksXHJcblx0XHRjb250ZW50OiBgPHA+JHtnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLkRpYWxvZ0NvbnRlbnRTdGF0dXNVcGRhdGVcIil9PC9wPmAsXHJcblx0XHRidXR0b25zOiBidXR0b25zLFxyXG5cdFx0ZGVmYXVsdDogXCJ5ZXNcIlxyXG5cdH0pLnJlbmRlcih0cnVlKTtcclxufVxyXG5cclxuLy8gXHJcbi8qKlxyXG4gKiBEaXNwbGF5IHRoZSBkaWFsb2d1ZSBhc2tpbmcgZWFjaCB1c2VyIGlmIHRoZXkgYXJlIHJlYWR5XHJcbiAqIFxyXG4gKiBAcGFyYW0gbWVzc2FnZSBUaGUgbWVzc2FnZSB0byBkaXNwbGF5IG9uIHRoZSBkaWFsb2d1ZS5cclxuICovXHJcbmZ1bmN0aW9uIGRpc3BsYXlSZWFkeUNoZWNrRGlhbG9nKG1lc3NhZ2U6IHN0cmluZykge1xyXG5cdGNvbnN0IGRhdGE6IFJlYWR5Q2hlY2tVc2VyRGF0YSA9IHsgYWN0aW9uOiAndXBkYXRlJywgcmVhZHk6IGZhbHNlLCB1c2VySWQ6IGdhbWUudXNlcklkID8/IFwiXCIsIGRpYWxvZzogbWVzc2FnZSB9O1xyXG5cdGNvbnN0IGJ1dHRvbnMgPSB7XHJcblx0XHR5ZXM6IHtcclxuXHRcdFx0aWNvbjogXCI8aSBjbGFzcz0nZmFzIGZhLWNoZWNrJz48L2k+XCIsXHJcblx0XHRcdGxhYmVsOiBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLlN0YXR1c1JlYWR5XCIpLFxyXG5cdFx0XHRjYWxsYmFjazogYXN5bmMgKCkgPT4geyBkYXRhLnJlYWR5ID0gdHJ1ZTsgYXdhaXQgdXBkYXRlUmVhZHlTdGF0dXMoZGF0YSk7IGF3YWl0IGRpc3BsYXlSZWFkeUNoZWNrQ2hhdE1lc3NhZ2UoZGF0YSk7IH1cclxuXHRcdH1cclxuXHR9O1xyXG5cclxuXHRuZXcgRGlhbG9nKHtcclxuXHRcdHRpdGxlOiBnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLkRpYWxvZ1RpdGxlUmVhZHlDaGVja1wiKSxcclxuXHRcdGNvbnRlbnQ6IGA8cD4ke2RhdGEuZGlhbG9nfTwvcD5gLFxyXG5cdFx0YnV0dG9uczogYnV0dG9ucyxcclxuXHRcdGRlZmF1bHQ6IFwieWVzXCJcclxuXHR9KS5yZW5kZXIodHJ1ZSk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBidXR0b24gbGlzdGVuZXIgdGhhdCBwZGF0ZXMgYSB1c2VyJ3MgcmVhZHkgc3RhdHVzLlxyXG4gKiBAcGFyYW0gZGF0YSBidXR0b24gY2xpY2sgZXZlbnQgZGF0YVxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gdXBkYXRlUmVhZHlTdGF0dXMoZGF0YTogUmVhZHlDaGVja1VzZXJEYXRhKSB7XHJcblx0Ly8gSWYgdGhlIHVzZXIgaXMgYSBHTSwganVzdCB1cGRhdGUgaXQgc2luY2UgdGhlIHNvY2tldCBnbyB0byB0aGUgc2VuZGVyLCBhbmQgbm9uZSBvZiB0aGUgcmVjaXBpZW50cyAocGxheWVycylcclxuXHQvLyB3aWxsIGhhdmUgdGhlIHBlcm1pc3Npb25zIHJlcXVpcmUgdG8gdXBkYXRlIHVzZXIgZmxhZ3MuIElmIHRoZSB1c2VyIGlzIG5vdCBhIEdNLCBlbWl0IHRoYXQgc29ja2V0LlxyXG5cdGlmIChpc1Byb3h5R00oZ2FtZS51c2VyKSkge1xyXG5cdFx0YXdhaXQgcHJvY2Vzc1JlYWR5UmVzcG9uc2UoZGF0YSk7XHJcblx0fSBlbHNlIGlmIChzb2NrZXQpIHtcclxuXHRcdHNvY2tldC5lbWl0KCdtb2R1bGUubWctcmVhZHktY2hlY2snLCBkYXRhKTtcclxuXHR9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBQcm9jZXNzIGEgKEdNKSdzIHJlYWR5IHJlcHNvbnNlLlxyXG4gKiBAcGFyYW0gZGF0YSBcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIHByb2Nlc3NSZWFkeVJlc3BvbnNlKGRhdGE6IFJlYWR5Q2hlY2tVc2VyRGF0YSkge1xyXG5cdGlmIChpc1Byb3h5R00oZ2FtZS51c2VyKSkge1xyXG5cdFx0Y29uc3QgdXNlclRvVXBkYXRlID0gZ2FtZS51c2Vycy5jb250ZW50cy5maW5kKCh1c2VyOiBVc2VyKSA9PiB1c2VyLmlkID09PSBkYXRhLnVzZXJJZCk7XHJcblx0XHRpZiAodXNlclRvVXBkYXRlKSB7XHJcblx0XHRcdGF3YWl0IHVzZXJUb1VwZGF0ZS5zZXRGbGFnKCdtZy1yZWFkeS1jaGVjaycsICdpc1JlYWR5JywgZGF0YS5yZWFkeSk7XHJcblx0XHRcdHVpLnBsYXllcnMucmVuZGVyKCk7XHJcblx0XHRcdGxldCBtZXNzYWdlID0gXCJcIjtcclxuXHRcdFx0aWYgKGFsbFVzZXJzSW5TY2VuZVJlYWR5KCkpIHtcclxuXHRcdFx0XHQvLyBVbnBhdXNlIHRoZSBnYW1lIGlmIHRoZSBzZXR0aW5nIHRvIGRvIHNvIGlzIGVuYWJsZWQuXHJcblx0XHRcdFx0aWYgKGdhbWUuc2V0dGluZ3MuZ2V0KCdtZy1yZWFkeS1jaGVjaycsICd1bnBhdXNlT25BbGxSZWFkeScpICYmIGdhbWUucGF1c2VkKSB7XHJcblx0XHRcdFx0XHRnYW1lLnRvZ2dsZVBhdXNlKGZhbHNlLCB0cnVlKTtcclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdGNvbnN0IHVzZXJzSW5TY2VuZSA9IGdldFVzZXJzV2l0aFRva2VuSW5TY2VuZSgpO1xyXG5cdFx0XHRcdGlmIChnYW1lLnNldHRpbmdzLmdldCgnbWctcmVhZHktY2hlY2snLCAnZW5hYmxlRGlzY29yZEludGVncmF0aW9uJylcclxuXHRcdFx0XHRcdCYmIHVzZXJzSW5TY2VuZS5maW5kKHVzZXIgPT4gdXNlci5pZCA9PT0gdXNlclRvVXBkYXRlLmlkKVxyXG5cdFx0XHRcdCkge1xyXG5cdFx0XHRcdFx0Ly8gV2Ugd2FudCB0byBvbmx5IHBpbmcgdGhlIEdNcyB0aGF0IGhhdmUgYSBzZXR0aW5nIGluZGljYXRpbmcgdGhhdCB0aGV5IHNob3VsZCBiZSBwaW5nZWQgZm9yIHRoaXMgbm90aWZpY2F0aW9uLlxyXG5cdFx0XHRcdFx0Z2FtZS51c2Vycy5jb250ZW50cy5mb3JFYWNoKCh1c2VyOiBVc2VyKSA9PiB7XHJcblx0XHRcdFx0XHRcdGNvbnN0IHNob3VsZFBpbmcgPSB1c2VyLmdldEZsYWcoJ2Rpc2NvcmQtaW50ZWdyYXRpb24nLCAnc2VuZEdNTm90aWZpY2F0aW9ucycpIGFzIGJvb2xlYW47XHJcblx0XHRcdFx0XHRcdGlmIChzaG91bGRQaW5nKSB7XHJcblx0XHRcdFx0XHRcdFx0bWVzc2FnZSArPSBgQCR7dXNlci5uYW1lfSBgO1xyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHRcdC8vIFNlbmQgYSBtZXNzYWdlIHRvIHRoZSBHTShzKSBpbmRpY2F0aW5nIHRoYXQgYWxsIHVzZXJzIGFyZSByZWFkeS5cclxuXHRcdFx0XHRcdG1lc3NhZ2UgKz0gZ2FtZS5pMThuLmxvY2FsaXplKFwiUkVBRFlDSEVDSy5BbGxQbGF5ZXJzUmVhZHlcIik7XHJcblxyXG5cdFx0XHRcdFx0SG9va3MuY2FsbEFsbChcInNlbmREaXNjb3JkTWVzc2FnZVwiLCBtZXNzYWdlKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH0gZWxzZSB7XHJcblx0XHRcdGNvbnNvbGUuZXJyb3IoYFRoZSB1c2VyIHdpdGggdGhlIGlkICR7ZGF0YS51c2VySWR9IHdhcyBub3QgZm91bmQuYCk7XHJcblx0XHR9XHJcblx0fVxyXG59XHJcblxyXG4vKipcclxuICogQ2hlY2tzIGlmIGFsbCB1c2VycyBpbiBhIHNjZW5lIGFyZSByZWFkeS5cclxuICogQHJldHVybnMgUmV0dXJucyB0cnVlIGlmIGFsbCB1c2VycyBhcmUgcmVhZHksIGZhbHNlIG90aGVyd2lzZS5cclxuICovXHJcbmZ1bmN0aW9uIGFsbFVzZXJzSW5TY2VuZVJlYWR5KCk6IGJvb2xlYW4ge1xyXG5cdGxldCB1c2Vyc1JlYWR5ID0gdHJ1ZTtcclxuXHRjb25zdCBzY2VuZVVzZXJzID0gZ2V0VXNlcnNXaXRoVG9rZW5JblNjZW5lKCk7XHJcblx0c2NlbmVVc2Vycy5mb3JFYWNoKCh1c2VyOiBVc2VyKSA9PiB7XHJcblx0XHRpZiAoIXVzZXIuZ2V0RmxhZygnbWctcmVhZHktY2hlY2snLCAnaXNSZWFkeScpKSB7XHJcblx0XHRcdHVzZXJzUmVhZHkgPSBmYWxzZTtcclxuXHRcdH1cclxuXHR9KTtcclxuXHRyZXR1cm4gdXNlcnNSZWFkeTtcclxufVxyXG5cclxuXHJcbi8qKlxyXG4gKiBEaXNwbGF5cyBhIGNoYXQgbWVzc2FnZSB3aGVuIGEgdXNlciByZXNwb25kcyB0byBhIHJlYWR5IGNoZWNrXHJcbiAqIFxyXG4gKiBAcGFyYW0gZGF0YSBldmVudCBkYXRhIGZyb20gY2xpY2tpbmcgZWl0aGVyIG9mIHRoZSBidXR0b25zIHRvIGluZGljYXRlIHJlYWR5L25vdCByZWFkeVxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gZGlzcGxheVJlYWR5Q2hlY2tDaGF0TWVzc2FnZShkYXRhOiBSZWFkeUNoZWNrVXNlckRhdGEpIHtcclxuXHRpZiAoZ2FtZS5zZXR0aW5ncy5nZXQoXCJtZy1yZWFkeS1jaGVja1wiLCBcInNob3dDaGF0TWVzc2FnZXNGb3JDaGVja3NcIikpIHtcclxuXHRcdC8vIEZpbmQgdGhlIGN1cnJlbnQgdXNlclxyXG5cdFx0Y29uc3QgY3VycmVudFVzZXIgPSBnYW1lLnVzZXJzLmNvbnRlbnRzLmZpbmQoKHVzZXI6IFVzZXIpID0+IHVzZXIuZGF0YS5faWQgPT09IGRhdGEudXNlcklkKTtcclxuXHRcdGlmIChjdXJyZW50VXNlcikge1xyXG5cdFx0XHRjb25zdCB1c2VybmFtZSA9IGN1cnJlbnRVc2VyLmRhdGEubmFtZTtcclxuXHRcdFx0Y29uc3QgY29udGVudCA9IGAke3VzZXJuYW1lfSAke2dhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suQ2hhdFRleHRDaGVja1wiKX1gO1xyXG5cdFx0XHRhd2FpdCBDaGF0TWVzc2FnZS5jcmVhdGUoeyBzcGVha2VyOiB7IGFsaWFzOiBcIlJlYWR5IFNldCBHbyFcIiB9LCBjb250ZW50OiBjb250ZW50IH0pO1xyXG5cdFx0fSBlbHNlIHtcclxuXHRcdFx0dGhyb3cgbmV3IEVycm9yKGBUaGUgdXNlciB3aXRoIHRoZSBpZCAke2RhdGEudXNlcklkfSB3YXMgbm90IGZvdW5kLmApO1xyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuXHJcbi8qKlxyXG4gKiBEaXNwbGF5IGEgY2hhdCBtZXNzYWdlIHdoZW4gYSB1c2VyIHVwZGF0ZXMgdGhlaXIgc3RhdHVzLlxyXG4gKiBAcGFyYW0gZGF0YSBldmVudCBkYXRhIGZyb20gY2xpY2tpbmcgZWl0aGVyIG9mIHRoZSBidXR0b25zIHRvIGluZGljYXRlIHJlYWR5L25vdCByZWFkeVxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gZGlzcGxheVN0YXR1c1VwZGF0ZUNoYXRNZXNzYWdlKGRhdGE6IFJlYWR5Q2hlY2tVc2VyRGF0YSkge1xyXG5cdGlmIChnYW1lLnNldHRpbmdzLmdldChcIm1nLXJlYWR5LWNoZWNrXCIsIFwic2hvd0NoYXRNZXNzYWdlc0ZvclVzZXJVcGRhdGVzXCIpKSB7XHJcblx0XHRjb25zdCBjdXJyZW50VXNlciA9IGdhbWUudXNlcnMuY29udGVudHMuZmluZCgodXNlcjogVXNlcikgPT4gdXNlci5pZCA9PT0gZGF0YS51c2VySWQpO1xyXG5cdFx0aWYgKGN1cnJlbnRVc2VyKSB7XHJcblx0XHRcdGNvbnN0IHVzZXJuYW1lID0gY3VycmVudFVzZXIuZGF0YS5uYW1lO1xyXG5cdFx0XHRjb25zdCBzdGF0dXMgPSBkYXRhLnJlYWR5ID8gZ2FtZS5pMThuLmxvY2FsaXplKFwiUkVBRFlDSEVDSy5TdGF0dXNSZWFkeVwiKSA6IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suU3RhdHVzTm90UmVhZHlcIik7XHJcblx0XHRcdGNvbnN0IGNvbnRlbnQgPSBgJHt1c2VybmFtZX0gJHtnYW1lLmkxOG4ubG9jYWxpemUoXCJSRUFEWUNIRUNLLkNoYXRUZXh0VXNlclVwZGF0ZVwiKX0gJHtzdGF0dXN9YDtcclxuXHRcdFx0YXdhaXQgQ2hhdE1lc3NhZ2UuY3JlYXRlKHsgc3BlYWtlcjogeyBhbGlhczogXCJSZWFkeSBTZXQgR28hXCIgfSwgY29udGVudDogY29udGVudCB9KTtcclxuXHRcdH0gZWxzZSB7XHJcblx0XHRcdHRocm93IG5ldyBFcnJvcihgVGhlIHVzZXIgd2l0aCB0aGUgaWQgJHtkYXRhLnVzZXJJZH0gd2FzIG5vdCBmb3VuZC5gKTtcclxuXHRcdH1cclxuXHR9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBQbGF5IHNvdW5kIGVmZmVjdCBhc3NvY2lhdGVkIHdpdGggcmVhZHkgY2hlY2sgc3RhcnRcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIHBsYXlSZWFkeUNoZWNrQWxlcnQoKSB7XHJcblx0Y29uc3QgcGxheUFsZXJ0ID0gZ2FtZS5zZXR0aW5ncy5nZXQoXCJtZy1yZWFkeS1jaGVja1wiLCBcInBsYXlBbGVydEZvckNoZWNrXCIpO1xyXG5cdGNvbnN0IGFsZXJ0U291bmQgPSBnYW1lLnNldHRpbmdzLmdldChcIm1nLXJlYWR5LWNoZWNrXCIsIFwiY2hlY2tBbGVydFNvdW5kUGF0aFwiKTtcclxuXHRpZiAocGxheUFsZXJ0ICYmICFhbGVydFNvdW5kKSB7XHJcblx0XHRhd2FpdCBBdWRpb0hlbHBlci5wbGF5KHsgc3JjOiBcIm1vZHVsZXMvbWctcmVhZHktY2hlY2svc291bmRzL25vdGlmaWNhdGlvbi5tcDNcIiwgdm9sdW1lOiAxLCBhdXRvcGxheTogdHJ1ZSwgbG9vcDogZmFsc2UgfSwgdHJ1ZSk7XHJcblx0fSBlbHNlIGlmIChwbGF5QWxlcnQgJiYgYWxlcnRTb3VuZCkge1xyXG5cdFx0YXdhaXQgQXVkaW9IZWxwZXIucGxheSh7IHNyYzogYWxlcnRTb3VuZCBhcyBzdHJpbmcsIHZvbHVtZTogMSwgYXV0b3BsYXk6IHRydWUsIGxvb3A6IGZhbHNlIH0sIHRydWUpO1xyXG5cdH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFVwZGF0ZXMgdGhlIHVpIG9mIGVhY2ggcGxheWVyJ3MgcmVhZHkgc3RhdHVzLlxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gdXBkYXRlUGxheWVyc1dpbmRvdygpIHtcclxuXHRjb25zdCBnYW1lVXNlcnMgPSBnYW1lLnVzZXJzLmNvbnRlbnRzXHJcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBnYW1lVXNlcnMubGVuZ3RoOyBpKyspIHtcclxuXHRcdC8vIElzIHRoZSB1c2VyIHJlYWR5XHJcblx0XHRjb25zdCByZWFkeSA9IGF3YWl0IGdhbWVVc2Vyc1tpXS5nZXRGbGFnKCdtZy1yZWFkeS1jaGVjaycsICdpc1JlYWR5Jyk7XHJcblx0XHQvLyB0aGUgSWQgb2YgdGhlIGN1cnJlbnQgdXNlclxyXG5cdFx0Y29uc3QgdXNlcklkOiBzdHJpbmcgPSBnYW1lVXNlcnNbaV0uZGF0YS5faWQ7XHJcblxyXG5cdFx0Ly8gZ2V0IHRoZSByZWFkeS9ub3QgcmVhZHkgaW5kaWNhdG9yXHJcblx0XHRjb25zdCBpbmRpY2F0b3IgPSAkKFwiI3BsYXllcnNcIikuZmluZChgW2RhdGEtdXNlci1pZD0ke3VzZXJJZH1dIC5jcmFzaC1yZWFkeS1pbmRpY2F0b3JgKTtcclxuXHRcdGNvbnN0IGluZGljYXRvckV4aXN0cyA9IGluZGljYXRvci5sZW5ndGggPiAwO1xyXG5cclxuXHRcdGxldCB0aXRsZTogc3RyaW5nXHJcblx0XHRsZXQgY2xhc3NUb0FkZCwgY2xhc3NUb1JlbW92ZSwgaWNvbkNsYXNzVG9BZGQsIGljb25DbGFzc1RvUmVtb3ZlO1xyXG5cclxuXHRcdGlmIChyZWFkeSkge1xyXG5cdFx0XHR0aXRsZSA9IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suUGxheWVyUmVhZHlcIik7XHJcblx0XHRcdGNsYXNzVG9BZGQgPSBcInJlYWR5XCI7XHJcblx0XHRcdGNsYXNzVG9SZW1vdmUgPSBcIm5vdC1yZWFkeVwiO1xyXG5cdFx0XHRpY29uQ2xhc3NUb0FkZCA9IFwiZmEtY2hlY2tcIjtcclxuXHRcdFx0aWNvbkNsYXNzVG9SZW1vdmUgPSBcImZhLXRpbWVzXCI7XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHR0aXRsZSA9IGdhbWUuaTE4bi5sb2NhbGl6ZShcIlJFQURZQ0hFQ0suUGxheWVyTm90UmVhZHlcIik7XHJcblx0XHRcdGNsYXNzVG9BZGQgPSBcIm5vdC1yZWFkeVwiO1xyXG5cdFx0XHRjbGFzc1RvUmVtb3ZlID0gXCJyZWFkeVwiO1xyXG5cdFx0XHRpY29uQ2xhc3NUb0FkZCA9IFwiZmEtdGltZXNcIjtcclxuXHRcdFx0aWNvbkNsYXNzVG9SZW1vdmUgPSBcImZhLWNoZWNrXCI7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKGluZGljYXRvckV4aXN0cykge1xyXG5cdFx0XHQkKGluZGljYXRvcikucmVtb3ZlQ2xhc3MoY2xhc3NUb1JlbW92ZSk7XHJcblx0XHRcdCQoaW5kaWNhdG9yKS5yZW1vdmVDbGFzcyhpY29uQ2xhc3NUb1JlbW92ZSk7XHJcblx0XHRcdCQoaW5kaWNhdG9yKS5hZGRDbGFzcyhjbGFzc1RvQWRkKTtcclxuXHRcdFx0JChpbmRpY2F0b3IpLmFkZENsYXNzKGljb25DbGFzc1RvQWRkKTtcclxuXHRcdH0gZWxzZSB7XHJcblx0XHRcdC8vIENyZWF0ZSBhIG5ldyBpbmRpY2F0b3JcclxuXHRcdFx0JChcIiNwbGF5ZXJzXCIpLmZpbmQoXCJbZGF0YS11c2VyLWlkPVwiICsgdXNlcklkICsgXCJdXCIpLmFwcGVuZChcclxuXHRcdFx0XHRhd2FpdCByZW5kZXJUZW1wbGF0ZShyZWFkeUluZGljYXRvckZpbGUsIHtcclxuXHRcdFx0XHRcdGljb25DbGFzc1RvQWRkOiBpY29uQ2xhc3NUb0FkZCxcclxuXHRcdFx0XHRcdGNsYXNzVG9BZGQ6IGNsYXNzVG9BZGQsXHJcblx0XHRcdFx0XHR0aXRsZTogdGl0bGVcclxuXHRcdFx0XHR9KVxyXG5cdFx0XHQpO1xyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuZnVuY3Rpb24gaXNQcm94eUdNKHVzZXI6IFVzZXIpOiBib29sZWFuIHtcclxuXHRjb25zdCBwcm94eUdNSWQgPSBnYW1lLnNldHRpbmdzLmdldChcIm1nLWxpdmluZy13b3JsZC1jb3JlXCIsIFwiR01Qcm94eVwiKTtcclxuXHRyZXR1cm4gdXNlci5pZCA9PT0gcHJveHlHTUlkO1xyXG59XHJcbi8qKlxyXG4gKiBkYXRhIHBhc3NlZCB0byBidXR0b24gbGlzdGVuZXIgZnVuY3Rpb25zXHJcbiAqL1xyXG5jbGFzcyBSZWFkeUNoZWNrVXNlckRhdGEge1xyXG5cdGFjdGlvbiA9IFwiXCI7XHJcblx0cmVhZHkgPSBmYWxzZTtcclxuXHR1c2VySWQgPSBcIlwiO1xyXG5cdGRpYWxvZz89IFwiXCI7XHJcbn1cclxuIl19
